﻿# Changelog

## 1.2.0 — 2026-11-18

### Interface
- Refined navigation icon animation behavior: icons animate only when their section is opened.
- Removed continuous hover-triggered icon motion.
- Added one-shot transitions that return icons to their normal resting state.
- Paused in-progress animations while the window is inactive or minimized.
- Kept the existing Win32 + GDI+ rendering path and Russian/English interface.

### Project
- Updated the application version and in-app version labels to 1.2.0.
- Updated Russian and English build documentation.
- Preserved existing page logic and domain modules.

## Previous development notes

The following entries are retained from the supplied source archive and describe earlier feature work.


## 2.0.1 — 2026-11-11

- Added asynchronous Update Checker using the public GitHub Releases API.
- Added manual update checks and a setting to enable or disable automatic checks at startup.
- Added release version comparison, release notes display and a link to the GitHub release page; downloading and installation remain user-controlled.

## 2.0.0 — 2026-11-10

- Expanded RegistryRepair to six typed parameters, including EnableCursorSuppression.
- Corrected typed registry writes for REG_DWORD and added a Windows Setup guard for SetupType/CmdLine.
- Added Recycle Bin cleanup and DNS resolver cache flushing.
- Added process context actions and a Windows Startup tab shortcut.
- Connected Diagnostics and Recovery shortcuts, including guarded WinRE behavior and UAC enablement with a `.reg` backup.
- Added BugCheck Event Log history, startup notifications, and TXT/HTML report export.
- Added a Disk Manager page with volume, file-system, disk-model, partition-style and supported health-prediction information.
- Fixed GUI subsystem configuration, UTF-8 compiler options, and the project icon path.
- Added classic `.sln` alongside `.slnx`, plus Russian and English build documentation.


## Visual polish
- Replaced the sidebar's inconsistent Unicode symbols with custom vector icons drawn by GDI+.
- Each navigation icon now has its own hover animation instead of sharing one horizontal pulse.
- Refined active navigation styling and the application brand mark.
