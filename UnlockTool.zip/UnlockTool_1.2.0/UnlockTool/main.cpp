﻿#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <shlobj.h>
#include <wincred.h>
#include <gdiplus.h>
#include <commctrl.h>

#include <algorithm>
#include <cmath>
#include <atomic>
#include <cstdint>
#include <memory>
#include <utility>
#include <string>
#include <thread>
#include <vector>
#include <sstream>
#include <iomanip>
#include <cwchar>

#include "resource.h"
#include "Cleanup.h"
#include "TaskManager.h"
#include "Users.h"
#include "UsersPage.h"
#include "RegistryPage.h"
#include "RegistryRepair.h"
#include "DiskManager.h"
#include "DiskManagerPage.h"
#include "BSODMonitor.h"
#include "BSODMonitorPage.h"
#include "DebuggerDetector.h"
#include "BootloaderRepair.h"
#include "AppearanceRepair.h"
#include "UpdateChecker.h"

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "netapi32.lib")
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "credui.lib")
#pragma comment(lib, "comctl32.lib")

using namespace Gdiplus;

namespace
{
    constexpr wchar_t APP_TITLE[] = L"UnlockTool";
    constexpr wchar_t WINDOW_CLASS[] = L"UnlockToolModernWindow";
    constexpr wchar_t APP_VERSION[] = L"1.2.0";

    constexpr int PAGE_COUNT = 10;
    constexpr int SIDEBAR_WIDTH = 238;
    constexpr int HEADER_HEIGHT = 82;
    constexpr int FOOTER_HEIGHT = 30;
    constexpr UINT WM_APP_UPDATE_COMPLETE = WM_APP + 41;
    constexpr UINT WM_APP_CLEANUP_COMPLETE = WM_APP + 42;
    constexpr UINT WM_APP_BOOT_COMPLETE = WM_APP + 43;

    constexpr UINT_PTR TIMER_TASK_REFRESH = 1;
    constexpr UINT_PTR TIMER_ANIMATION = 2;
    constexpr UINT TASK_REFRESH_MS = 1800;

    enum Page
    {
        PAGE_HOME = 0,
        PAGE_TASKS,
        PAGE_USERS,
        PAGE_DIAGNOSTICS,
        PAGE_RECOVERY,
        PAGE_CLEANUP,
        PAGE_BSOD,
        PAGE_REGISTRY,
        PAGE_DISKS,
        PAGE_SETTINGS
    };

    enum Hit
    {
        HIT_NONE = 0,
        HIT_NAV,
        HIT_TASK_REFRESH,
        HIT_TASK_STARTUP,
        HIT_TASK_END,
        HIT_TASK_SUSPEND,
        HIT_TASK_RESUME,
        HIT_TASK_ROW,
        HIT_CLEANUP_SCAN,
        HIT_CLEANUP_RUN,
        HIT_CLEANUP_TOGGLE,
        HIT_USER_REFRESH,
        HIT_USER_CREATE,
        HIT_USER_ENABLE,
        HIT_USER_DISABLE,
        HIT_USER_PASSWORD,
        HIT_USER_DELETE,
        HIT_USER_ROW,
        HIT_DIAG_SYSTEM,
        HIT_DIAG_SFC,
        HIT_DIAG_SERVICES,
        HIT_DIAG_DEBUG_SCAN,
        HIT_DEBUG_ROW,
        HIT_DEBUG_REMOVE,
        HIT_RECOVERY_SFC,
        HIT_RECOVERY_DISM,
        HIT_RECOVERY_CHKDSK,
        HIT_RECOVERY_WINRE,
        HIT_RECOVERY_UAC,
        HIT_RECOVERY_BOOT,
        HIT_BSOD_REFRESH,
        HIT_BSOD_DUMPS,
        HIT_BSOD_EVENT,
        HIT_BSOD_RELIABILITY,
        HIT_BSOD_EXPORT,
        HIT_BSOD_ROW,
        HIT_SETTING_LANGUAGE,
        HIT_SETTING_AUTOCHECK,
        HIT_SETTING_AUTOSTART,
        HIT_SETTING_NOTIFICATIONS,
        HIT_SETTING_ANIMATIONS,
        HIT_SETTING_APPEARANCE,
        HIT_SETTING_UPDATE,
        HIT_REGISTRY_REFRESH,
        HIT_REGISTRY_ROW,
        HIT_REGISTRY_RESTORE,
        HIT_REGISTRY_EDIT,
        HIT_DISK_ROW,
        HIT_DISK_OPEN,
        HIT_DISK_SCAN,
        HIT_DISK_BITLOCKER,
        HIT_DISK_MANAGEMENT
    };

    struct HitRegion
    {
        RECT rect{};
        Hit hit = HIT_NONE;
        int data = 0;
    };

    struct CleanupPayload
    {
        std::vector<Cleanup::CleanupItem> items;
        bool clean = false;
        bool success = true;
        std::wstring message;
    };

    struct BootPayload
    {
        BootloaderRepair::RepairResult result;
    };

    struct UpdatePayload
    {
        bool interactive = false;
        UpdateChecker::Result* result = nullptr;
    };

    ULONG_PTR gdiplusToken = 0;
    HWND mainWindow = nullptr;
    HINSTANCE appInstance = nullptr;

    int currentPage = PAGE_HOME;
    int previousPage = PAGE_HOME;
    int language = 0;
    bool animationsEnabled = true;
    bool notificationsEnabled = true;
    bool autoCheckUpdates = true;
    bool autoStartEnabled = false;
    bool updateRunning = false;
    bool cleanupRunning = false;
    bool bootRunning = false;
    bool processSearchFocused = false;
    bool taskListLoaded = false;
    bool registryLoaded = false;
    bool usersLoaded = false;
    bool disksLoaded = false;
    bool bsodLoaded = false;
    bool debuggerLoaded = false;
    NOTIFYICONDATAW bsodTrayIcon{};
    bool bsodTrayIconAdded = false;

    float pageTransition = 1.0f;
    float navIconAnimation = 1.0f;
    int animatedNavPage = -1;
    int hoveredNav = -1;
    bool windowIsActive = true;
    int selectedTask = -1;
    int selectedUser = -1;
    int selectedDisk = -1;
    int selectedIncident = -1;
    int selectedRegistry = -1;
    int selectedDebugger = -1;
    int taskScroll = 0;

    std::wstring statusText;
    std::wstring processSearch;
    std::wstring settingsPath;
    std::vector<HitRegion> hitRegions;

    std::vector<TaskManager::ProcessInfo> processes;
    std::vector<Cleanup::CleanupItem> cleanupItems;
    std::vector<Users::UserInfo> users;
    std::vector<RegistryRepair::ParameterInfo> registryItems;
    std::vector<DiskManager::VolumeInfo> disks;
    std::vector<BSODMonitor::Incident> incidents;
    std::vector<DebuggerDetector::DebuggerEntry> debuggerEntries;

    const wchar_t* pageNames[2][PAGE_COUNT] =
    {
        { L"Главная", L"Диспетчер задач", L"Пользователи", L"Диагностика",
          L"Восстановление", L"Очистка системы", L"Монитор BSOD",
          L"Реестр", L"Диски", L"Настройки" },
        { L"Home", L"Task Manager", L"Users", L"Diagnostics",
          L"Recovery", L"System Cleanup", L"BSOD Monitor",
          L"Registry", L"Disk Manager", L"Settings" }
    };

    const wchar_t* pageSubtitles[2][PAGE_COUNT] =
    {
        { L"Состояние компьютера и быстрые действия", L"Процессы и использование ресурсов",
          L"Локальные учётные записи Windows", L"Инструменты проверки и анализа",
          L"Восстановление компонентов и загрузки Windows", L"Анализ и удаление временных данных",
          L"История критических системных ошибок", L"Проверка и восстановление системных параметров",
          L"Тома, разделы и файловые системы", L"Параметры приложения" },
        { L"System status and quick actions", L"Processes and resource usage",
          L"Local Windows accounts", L"Inspection and analysis tools",
          L"Windows component and boot recovery", L"Analyze and remove temporary data",
          L"History of critical system errors", L"Inspect and repair system parameters",
          L"Volumes, partitions and file systems", L"Application preferences" }
    };

    const Color C_BG(255, 13, 18, 25);
    const Color C_SIDEBAR(255, 17, 24, 33);
    const Color C_HEADER(255, 18, 26, 36);
    const Color C_SURFACE(255, 24, 34, 46);
    const Color C_SURFACE_2(255, 29, 42, 56);
    const Color C_SURFACE_HOVER(255, 37, 54, 72);
    const Color C_BORDER(255, 47, 64, 81);
    const Color C_TEXT(255, 235, 241, 247);
    const Color C_MUTED(255, 145, 163, 181);
    const Color C_FAINT(255, 104, 123, 143);
    const Color C_ACCENT(255, 65, 143, 214);
    const Color C_ACCENT_SOFT(255, 36, 76, 111);
    const Color C_GREEN(255, 77, 183, 132);
    const Color C_AMBER(255, 224, 168, 76);
    const Color C_RED(255, 220, 91, 91);

    std::wstring L(const wchar_t* ru, const wchar_t* en)
    {
        return language == 0 ? ru : en;
    }

    std::wstring L(const wchar_t* text)
    {
        return text ? text : L"";
    }

    void AddHit(const RECT& r, Hit h, int data = 0)
    {
        hitRegions.push_back({ r, h, data });
    }

    bool Contains(const RECT& r, int x, int y)
    {
        return x >= r.left && x < r.right && y >= r.top && y < r.bottom;
    }

    RECT MakeRect(int x, int y, int w, int h)
    {
        return RECT{ x, y, x + w, y + h };
    }

    void Fill(Graphics& g, const RECT& r, const Color& color)
    {
        SolidBrush b(color);
        g.FillRectangle(
            &b,
            static_cast<INT>(r.left),
            static_cast<INT>(r.top),
            static_cast<INT>(r.right - r.left),
            static_cast<INT>(r.bottom - r.top)
        );
    }

    void Stroke(Graphics& g, const RECT& r, const Color& color, float width = 1.0f)
    {
        Pen p(color, width);
        g.DrawRectangle(
            &p,
            static_cast<INT>(r.left),
            static_cast<INT>(r.top),
            static_cast<INT>(r.right - r.left - 1),
            static_cast<INT>(r.bottom - r.top - 1)
        );
    }

    void FillRound(Graphics& g, const RECT& r, const Color& color, int radius = 7)
    {
        GraphicsPath path;
        const REAL x = static_cast<REAL>(r.left);
        const REAL y = static_cast<REAL>(r.top);
        const REAL w = static_cast<REAL>(r.right - r.left);
        const REAL h = static_cast<REAL>(r.bottom - r.top);
        const REAL d = static_cast<REAL>(radius * 2);
        path.AddArc(x, y, d, d, 180, 90);
        path.AddArc(x + w - d, y, d, d, 270, 90);
        path.AddArc(x + w - d, y + h - d, d, d, 0, 90);
        path.AddArc(x, y + h - d, d, d, 90, 90);
        path.CloseFigure();
        SolidBrush b(color);
        g.FillPath(&b, &path);
    }

    void DrawLabel(Graphics& g, const std::wstring& text, const RECT& r,
        float size = 10.0f, const Color& color = C_TEXT,
        bool bold = false, StringAlignment align = StringAlignmentNear)
    {
        Font font(L"Segoe UI", size, bold ? FontStyleBold : FontStyleRegular, UnitPixel);
        SolidBrush brush(color);
        StringFormat fmt;
        fmt.SetAlignment(align);
        fmt.SetLineAlignment(StringAlignmentCenter);
        fmt.SetTrimming(StringTrimmingEllipsisCharacter);
        fmt.SetFormatFlags(StringFormatFlagsNoWrap);
        g.DrawString(text.c_str(), -1, &font,
            RectF(static_cast<REAL>(r.left), static_cast<REAL>(r.top),
                static_cast<REAL>(r.right - r.left), static_cast<REAL>(r.bottom - r.top)),
            &fmt, &brush);
    }

    void Text(Graphics& g, const std::wstring& s, int x, int y, int w, int h,
        float size = 10.0f, const Color& c = C_TEXT, bool bold = false)
    {
        DrawLabel(g, s, MakeRect(x, y, w, h), size, c, bold);
    }

    void DrawButton(Graphics& g, const RECT& r, const std::wstring& label,
        bool primary = false, bool disabled = false)
    {
        const Color fill = disabled ? Color(255, 35, 44, 54)
            : primary ? C_ACCENT : C_SURFACE_2;
        FillRound(g, r, fill, 6);
        if (!primary && !disabled)
            Stroke(g, r, C_BORDER);
        DrawLabel(g, label, r, 10, disabled ? C_FAINT : C_TEXT, true, StringAlignmentCenter);
    }

    void Button(Graphics& g, int x, int y, int w, int h, const std::wstring& label,
        Hit hit, int data = 0, bool primary = false, bool disabled = false)
    {
        RECT r = MakeRect(x, y, w, h);
        DrawButton(g, r, label, primary, disabled);
        if (!disabled) AddHit(r, hit, data);
    }

    void DrawSectionTitle(Graphics& g, const std::wstring& title,
        const std::wstring& subtitle, int x, int y, int width)
    {
        Text(g, title, x, y, width, 32, 21, C_TEXT, true);
        Text(g, subtitle, x, y + 34, width, 22, 10, C_MUTED);
    }

    void DrawPanel(Graphics& g, const RECT& r, const std::wstring& title = L"")
    {
        FillRound(g, r, C_SURFACE, 8);
        Stroke(g, r, C_BORDER);
        if (!title.empty())
            Text(g, title, r.left + 16, r.top + 9, r.right - r.left - 32, 26, 11, C_TEXT, true);
    }

    std::wstring FormatBytes(uint64_t bytes)
    {
        const wchar_t* units[] = { L"B", L"KB", L"MB", L"GB", L"TB" };
        double v = static_cast<double>(bytes);
        int unit = 0;
        while (v >= 1024.0 && unit < 4) { v /= 1024.0; ++unit; }
        wchar_t b[64]{};
        swprintf_s(b, L"%.1f %s", v, units[unit]);
        return b;
    }

    std::wstring FormatNumber(uint64_t n)
    {
        std::wstring s = std::to_wstring(n);
        for (int i = static_cast<int>(s.size()) - 3; i > 0; i -= 3)
            s.insert(static_cast<size_t>(i), L",");
        return s;
    }

    void SetStatus(const std::wstring& text)
    {
        statusText = text;
        if (mainWindow) InvalidateRect(mainWindow, nullptr, FALSE);
    }

    struct PromptState
    {
        std::wstring title;
        std::wstring label;
        std::wstring initial;
        std::wstring result;
        HWND edit = nullptr;
        bool accepted = false;
    };

    LRESULT CALLBACK PromptWindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
    {
        auto* state = reinterpret_cast<PromptState*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (message == WM_NCCREATE)
        {
            auto* cs = reinterpret_cast<CREATESTRUCTW*>(lParam);
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(cs->lpCreateParams));
            return TRUE;
        }
        if (message == WM_CREATE && state)
        {
            CreateWindowExW(0, L"STATIC", state->label.c_str(), WS_CHILD | WS_VISIBLE,
                16, 14, 430, 38, hwnd, nullptr, appInstance, nullptr);
            state->edit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", state->initial.c_str(),
                WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
                16, 56, 430, 28, hwnd, reinterpret_cast<HMENU>(1001), appInstance, nullptr);
            CreateWindowExW(0, L"BUTTON", L"OK", WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON,
                286, 98, 76, 28, hwnd, reinterpret_cast<HMENU>(IDOK), appInstance, nullptr);
            CreateWindowExW(0, L"BUTTON", L"Отмена", WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                370, 98, 76, 28, hwnd, reinterpret_cast<HMENU>(IDCANCEL), appInstance, nullptr);
            SendMessageW(state->edit, EM_SETSEL, 0, -1);
            SetFocus(state->edit);
            return 0;
        }
        if (message == WM_COMMAND && state)
        {
            if (LOWORD(wParam) == IDOK)
            {
                int length = GetWindowTextLengthW(state->edit);
                state->result.assign(static_cast<size_t>((std::max)(0, length)) + 1, L'\0');
                GetWindowTextW(state->edit, state->result.data(), length + 1);
                state->result.resize(static_cast<size_t>((std::max)(0, length)));
                state->accepted = true;
                DestroyWindow(hwnd);
                return 0;
            }
            if (LOWORD(wParam) == IDCANCEL)
            {
                DestroyWindow(hwnd);
                return 0;
            }
        }
        if (message == WM_CLOSE) { DestroyWindow(hwnd); return 0; }
        return DefWindowProcW(hwnd, message, wParam, lParam);
    }

    bool PromptForText(HWND owner, const std::wstring& title, const std::wstring& label,
        const std::wstring& initial, std::wstring& result)
    {
        static bool registered = false;
        if (!registered)
        {
            WNDCLASSW wc{};
            wc.lpfnWndProc = PromptWindowProc;
            wc.hInstance = appInstance;
            wc.lpszClassName = L"UnlockToolPromptWindow";
            wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
            wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
            if (!RegisterClassW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return false;
            registered = true;
        }

        PromptState state{ title, label, initial };
        HWND window = CreateWindowExW(WS_EX_DLGMODALFRAME, L"UnlockToolPromptWindow",
            title.c_str(), WS_CAPTION | WS_SYSMENU | WS_POPUP,
            CW_USEDEFAULT, CW_USEDEFAULT, 480, 180, owner, nullptr, appInstance, &state);
        if (!window) return false;
        RECT wr{}; GetWindowRect(window, &wr);
        RECT orc{}; GetWindowRect(owner, &orc);
        SetWindowPos(window, HWND_TOP,
            orc.left + ((orc.right - orc.left) - (wr.right - wr.left)) / 2,
            orc.top + ((orc.bottom - orc.top) - (wr.bottom - wr.top)) / 2,
            0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
        EnableWindow(owner, FALSE);
        MSG msg{};
        while (IsWindow(window) && GetMessageW(&msg, nullptr, 0, 0) > 0)
        {
            if (!IsDialogMessageW(window, &msg))
            {
                TranslateMessage(&msg);
                DispatchMessageW(&msg);
            }
        }
        EnableWindow(owner, TRUE);
        SetActiveWindow(owner);
        if (state.accepted) result = state.result;
        return state.accepted;
    }

    struct StartupEntry
    {
        std::wstring source;
        std::wstring name;
        std::wstring command;
    };

    void ReadStartupRunKey(HKEY root, const wchar_t* path, const wchar_t* label,
        std::vector<StartupEntry>& entries)
    {
        HKEY key = nullptr;
        if (RegOpenKeyExW(root, path, 0, KEY_QUERY_VALUE | KEY_WOW64_64KEY, &key) != ERROR_SUCCESS)
        {
            if (RegOpenKeyExW(root, path, 0, KEY_QUERY_VALUE, &key) != ERROR_SUCCESS) return;
        }
        for (DWORD index = 0; ; ++index)
        {
            wchar_t name[512]{};
            BYTE data[8192]{};
            DWORD nameSize = static_cast<DWORD>(_countof(name));
            DWORD dataSize = sizeof(data);
            DWORD type = 0;
            LONG rc = RegEnumValueW(key, index, name, &nameSize, nullptr, &type, data, &dataSize);
            if (rc == ERROR_NO_MORE_ITEMS) break;
            if (rc != ERROR_SUCCESS) continue;
            if (type != REG_SZ && type != REG_EXPAND_SZ) continue;
            const wchar_t* value = reinterpret_cast<const wchar_t*>(data);
            size_t chars = dataSize / sizeof(wchar_t);
            std::wstring command(value, value + chars);
            while (!command.empty() && command.back() == L'\0') command.pop_back();
            entries.push_back({ label, name, command });
        }
        RegCloseKey(key);
    }

    struct StartupWindowState
    {
        std::vector<StartupEntry> entries;
        HWND list = nullptr;
    };

    LRESULT CALLBACK StartupWindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
    {
        auto* state = reinterpret_cast<StartupWindowState*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (message == WM_NCCREATE)
        {
            auto* cs = reinterpret_cast<CREATESTRUCTW*>(lParam);
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(cs->lpCreateParams));
            return TRUE;
        }
        if (message == WM_CREATE && state)
        {
            CreateWindowExW(0, L"STATIC",
                L"Записи из разделов Run текущего пользователя и всей системы",
                WS_CHILD | WS_VISIBLE, 16, 12, 650, 24, hwnd, nullptr, appInstance, nullptr);
            state->list = CreateWindowExW(WS_EX_CLIENTEDGE, L"LISTBOX", nullptr,
                WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | LBS_NOINTEGRALHEIGHT,
                16, 42, 650, 330, hwnd, reinterpret_cast<HMENU>(1002), appInstance, nullptr);
            for (const auto& entry : state->entries)
            {
                std::wstring row = L"[" + entry.source + L"] " + entry.name + L"    —    " + entry.command;
                SendMessageW(state->list, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(row.c_str()));
            }
            if (state->entries.empty())
                SendMessageW(state->list, LB_ADDSTRING, 0,
                    reinterpret_cast<LPARAM>(L"Записи автозагрузки Run не найдены."));
            CreateWindowExW(0, L"BUTTON", L"Закрыть",
                WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON,
                580, 386, 86, 30, hwnd, reinterpret_cast<HMENU>(IDOK), appInstance, nullptr);
            return 0;
        }
        if (message == WM_COMMAND && LOWORD(wParam) == IDOK)
        {
            DestroyWindow(hwnd);
            return 0;
        }
        if (message == WM_CLOSE) { DestroyWindow(hwnd); return 0; }
        return DefWindowProcW(hwnd, message, wParam, lParam);
    }

    void ShowStartupEntries(HWND owner)
    {
        std::vector<StartupEntry> entries;
        ReadStartupRunKey(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Run", L"Текущий пользователь", entries);
        ReadStartupRunKey(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", L"Все пользователи", entries);

        static bool registered = false;
        if (!registered)
        {
            WNDCLASSW wc{};
            wc.lpfnWndProc = StartupWindowProc;
            wc.hInstance = appInstance;
            wc.lpszClassName = L"UnlockToolStartupWindow";
            wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
            wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
            if (!RegisterClassW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return;
            registered = true;
        }

        StartupWindowState state{ std::move(entries) };
        HWND window = CreateWindowExW(WS_EX_DLGMODALFRAME, L"UnlockToolStartupWindow",
            L"Автозагрузка Windows", WS_CAPTION | WS_SYSMENU | WS_POPUP,
            CW_USEDEFAULT, CW_USEDEFAULT, 700, 470, owner, nullptr, appInstance, &state);
        if (!window) return;
        RECT wr{}; GetWindowRect(window, &wr);
        RECT orc{}; GetWindowRect(owner, &orc);
        SetWindowPos(window, HWND_TOP,
            orc.left + ((orc.right - orc.left) - (wr.right - wr.left)) / 2,
            orc.top + ((orc.bottom - orc.top) - (wr.bottom - wr.top)) / 2,
            0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
        EnableWindow(owner, FALSE);
        MSG msg{};
        while (IsWindow(window) && GetMessageW(&msg, nullptr, 0, 0) > 0)
        {
            if (!IsDialogMessageW(window, &msg))
            {
                TranslateMessage(&msg);
                DispatchMessageW(&msg);
            }
        }
        EnableWindow(owner, TRUE);
        SetActiveWindow(owner);
    }

    void InitializeSettings()
    {
        wchar_t local[MAX_PATH]{};
        if (SUCCEEDED(SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr,
            SHGFP_TYPE_CURRENT, local)))
        {
            std::wstring folder = std::wstring(local) + L"\\UnlockTool";
            CreateDirectoryW(folder.c_str(), nullptr);
            settingsPath = folder + L"\\settings.ini";
        }

        if (settingsPath.empty()) return;
        language = GetPrivateProfileIntW(L"General", L"Language", 0, settingsPath.c_str());
        if (language < 0 || language > 1) language = 0;
        animationsEnabled = GetPrivateProfileIntW(L"General", L"Animations", 1, settingsPath.c_str()) != 0;
        autoStartEnabled = GetPrivateProfileIntW(L"General", L"AutoStart", 0, settingsPath.c_str()) != 0;
        autoCheckUpdates = GetPrivateProfileIntW(L"Updates", L"AutoCheck", 1, settingsPath.c_str()) != 0;
        notificationsEnabled = GetPrivateProfileIntW(L"Notifications", L"Enabled", 1, settingsPath.c_str()) != 0;
    }

    void WriteSetting(const wchar_t* section, const wchar_t* key, bool value)
    {
        if (!settingsPath.empty())
            WritePrivateProfileStringW(section, key, value ? L"1" : L"0", settingsPath.c_str());
    }

    void SaveLanguage()
    {
        if (!settingsPath.empty())
        {
            wchar_t b[8]{};
            wsprintfW(b, L"%d", language);
            WritePrivateProfileStringW(L"General", L"Language", b, settingsPath.c_str());
        }
    }

    bool IsStartupEnabled()
    {
        HKEY key = nullptr;
        if (RegOpenKeyExW(HKEY_CURRENT_USER,
            L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
            0, KEY_QUERY_VALUE, &key) != ERROR_SUCCESS) return false;
        DWORD type = 0, size = 0;
        LONG r = RegQueryValueExW(key, L"UnlockTool", nullptr, &type, nullptr, &size);
        RegCloseKey(key);
        return r == ERROR_SUCCESS && (type == REG_SZ || type == REG_EXPAND_SZ);
    }

    bool SetStartupEnabled(bool enabled)
    {
        HKEY key = nullptr;
        if (RegCreateKeyExW(HKEY_CURRENT_USER,
            L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
            0, nullptr, 0, KEY_SET_VALUE, nullptr, &key, nullptr) != ERROR_SUCCESS)
            return false;
        LONG result = ERROR_SUCCESS;
        if (enabled)
        {
            wchar_t exe[MAX_PATH]{};
            DWORD n = GetModuleFileNameW(nullptr, exe, MAX_PATH);
            if (!n || n >= MAX_PATH) { RegCloseKey(key); return false; }
            std::wstring command = L"\"" + std::wstring(exe) + L"\"";
            result = RegSetValueExW(key, L"UnlockTool", 0, REG_SZ,
                reinterpret_cast<const BYTE*>(command.c_str()),
                static_cast<DWORD>((command.size() + 1) * sizeof(wchar_t)));
        }
        else
        {
            result = RegDeleteValueW(key, L"UnlockTool");
            if (result == ERROR_FILE_NOT_FOUND) result = ERROR_SUCCESS;
        }
        RegCloseKey(key);
        return result == ERROR_SUCCESS;
    }

    bool IsWinRE()
    {
        wchar_t value[16]{};
        DWORD size = sizeof(value);
        HKEY key = nullptr;
        if (RegOpenKeyExW(HKEY_LOCAL_MACHINE,
            L"SYSTEM\\CurrentControlSet\\Control\\MiniNT",
            0, KEY_QUERY_VALUE, &key) == ERROR_SUCCESS)
        {
            RegCloseKey(key);
            return true;
        }
        return false;
    }

    bool LaunchElevated(const std::wstring& command)
    {
        SHELLEXECUTEINFOW sei{};
        sei.cbSize = sizeof(sei);
        sei.fMask = SEE_MASK_NOCLOSEPROCESS;
        sei.lpVerb = L"runas";
        sei.lpFile = L"cmd.exe";
        std::wstring args = L"/k " + command;
        sei.lpParameters = args.c_str();
        sei.nShow = SW_SHOWNORMAL;
        if (!ShellExecuteExW(&sei)) return false;
        if (sei.hProcess) CloseHandle(sei.hProcess);
        return true;
    }

    bool LaunchSystem(const wchar_t* file, const wchar_t* args = nullptr, bool elevated = false)
    {
        HINSTANCE r = ShellExecuteW(mainWindow, elevated ? L"runas" : L"open",
            file, args, nullptr, SW_SHOWNORMAL);
        return reinterpret_cast<INT_PTR>(r) > 32;
    }

    void RefreshProcesses()
    {
        DWORD selectedPid = 0;
        if (selectedTask >= 0 && selectedTask < static_cast<int>(processes.size()))
            selectedPid = processes[selectedTask].pid;
        processes = TaskManager::GetProcesses();
        taskListLoaded = true;
        selectedTask = -1;
        if (selectedPid != 0)
        {
            for (int i = 0; i < static_cast<int>(processes.size()); ++i)
                if (processes[i].pid == selectedPid) { selectedTask = i; break; }
        }
    }

    void LoadUsers()
    {
        users.clear();
        usersLoaded = Users::GetUsers(users) == NERR_Success;
        if (selectedUser >= static_cast<int>(users.size())) selectedUser = -1;
    }

    void LoadRegistry()
    {
        RegistryRepair::Parameter params[] = {
            RegistryRepair::Parameter::Shell,
            RegistryRepair::Parameter::Userinit,
            RegistryRepair::Parameter::CmdLine,
            RegistryRepair::Parameter::AppInitDlls,
            RegistryRepair::Parameter::SetupType,
            RegistryRepair::Parameter::CursorSuppression,
            RegistryRepair::Parameter::BootExecute
        };
        registryItems.clear();
        for (auto p : params)
        {
            RegistryRepair::ParameterInfo info{};
            RegistryRepair::ReadParameter(p, info);
            registryItems.push_back(std::move(info));
        }
        registryLoaded = true;
        if (selectedRegistry >= static_cast<int>(registryItems.size())) selectedRegistry = -1;
    }

    void LoadDisks()
    {
        disks = DiskManager::EnumerateVolumes();
        disksLoaded = true;
        if (selectedDisk >= static_cast<int>(disks.size())) selectedDisk = -1;
    }

    void LoadBsod()
    {
        incidents = BSODMonitor::GetIncidents(50);
        bsodLoaded = true;
        selectedIncident = incidents.empty() ? -1 : 0;
    }

    void LoadDebuggerEntries()
    {
        debuggerEntries = DebuggerDetector::Scan();
        debuggerLoaded = true;
        if (selectedDebugger >= static_cast<int>(debuggerEntries.size())) selectedDebugger = -1;
    }

    void RemoveBsodTrayIcon()
    {
        if (bsodTrayIconAdded)
        {
            Shell_NotifyIconW(NIM_DELETE, &bsodTrayIcon);
            bsodTrayIconAdded = false;
        }
    }

    void MarkBsodIncidentsViewed()
    {
        if (settingsPath.empty()) return;
        const auto latest = BSODMonitor::GetIncidents(1);
        if (!latest.empty() && !latest.front().timestamp.empty())
            WritePrivateProfileStringW(L"BSODMonitor", L"LastSeenTimestamp",
                latest.front().timestamp.c_str(), settingsPath.c_str());
        RemoveBsodTrayIcon();
    }

    void CheckBsodStartupNotification(HWND hwnd)
    {
        if (!notificationsEnabled || settingsPath.empty()) return;
        const auto latest = BSODMonitor::GetIncidents(1);
        if (latest.empty() || latest.front().timestamp.empty()) return;
        wchar_t lastSeen[128]{};
        GetPrivateProfileStringW(L"BSODMonitor", L"LastSeenTimestamp", L"",
            lastSeen, 128, settingsPath.c_str());
        if (latest.front().timestamp == lastSeen) return;

        bsodTrayIcon = NOTIFYICONDATAW{};
        bsodTrayIcon.cbSize = sizeof(bsodTrayIcon);
        bsodTrayIcon.hWnd = hwnd;
        bsodTrayIcon.uID = 2;
        bsodTrayIcon.uFlags = NIF_ICON | NIF_TIP;
        bsodTrayIcon.hIcon = LoadIconW(appInstance, MAKEINTRESOURCEW(IDI_APP_ICON));
        if (!bsodTrayIcon.hIcon) bsodTrayIcon.hIcon = LoadIconW(nullptr, IDI_WARNING);
        wcscpy_s(bsodTrayIcon.szTip, L"UnlockTool — BSOD Monitor");
        if (Shell_NotifyIconW(NIM_ADD, &bsodTrayIcon))
        {
            bsodTrayIconAdded = true;
            bsodTrayIcon.uFlags = NIF_INFO;
            wcscpy_s(bsodTrayIcon.szInfoTitle,
                language == 0 ? L"UnlockTool: обнаружен BSOD" : L"UnlockTool: BSOD detected");
            wcscpy_s(bsodTrayIcon.szInfo,
                language == 0
                    ? L"В журнале Windows обнаружена новая запись BugCheck. Откройте BSOD Monitor."
                    : L"A new BugCheck event was found in Windows Event Log. Open BSOD Monitor.");
            bsodTrayIcon.dwInfoFlags = NIIF_WARNING;
            bsodTrayIcon.uTimeout = 8000;
            Shell_NotifyIconW(NIM_MODIFY, &bsodTrayIcon);
        }
    }

    void LoadCleanup()
    {
        cleanupItems = Cleanup::GetCleanupItems();
    }

    void Navigate(int page)
    {
        if (page < 0 || page >= PAGE_COUNT || page == currentPage) return;
        previousPage = currentPage;
        currentPage = page;
        pageTransition = animationsEnabled ? 0.0f : 1.0f;
        animatedNavPage = page;
        navIconAnimation = animationsEnabled ? 0.0f : 1.0f;
        if (animationsEnabled && windowIsActive)
            SetTimer(mainWindow, TIMER_ANIMATION, 16, nullptr);
        if (page == PAGE_TASKS && !taskListLoaded) RefreshProcesses();
        if (page == PAGE_USERS && !usersLoaded) LoadUsers();
        if (page == PAGE_CLEANUP && cleanupItems.empty()) LoadCleanup();
        if (page == PAGE_BSOD)
        {
            if (!bsodLoaded) LoadBsod();
            MarkBsodIncidentsViewed();
        }
        if (page == PAGE_REGISTRY && !registryLoaded) LoadRegistry();
        if (page == PAGE_DISKS && !disksLoaded) LoadDisks();
        if (page == PAGE_DIAGNOSTICS && !debuggerLoaded) LoadDebuggerEntries();
        SetStatus(L(L"Открыт раздел: ", L"Opened: ") + pageNames[language][page]);
        InvalidateRect(mainWindow, nullptr, FALSE);
    }

    void DrawBrand(Graphics& g)
    {
        RECT logo = MakeRect(18, 18, 42, 42);
        FillRound(g, MakeRect(15, 15, 48, 48), C_ACCENT_SOFT, 12);
        FillRound(g, logo, C_ACCENT, 9);
        Text(g, L"U", logo.left, logo.top - 1, logo.right - logo.left, logo.bottom - logo.top + 2,
            24, Color(255,255,255,255), true);
        Text(g, L"UnlockTool", 74, 17, 145, 27, 16, C_TEXT, true);
        Text(g, L"WINDOWS  •  SYSTEM CARE", 75, 43, 150, 16, 7.5f, C_MUTED, true);
    }


    void DrawRoundOutline(Graphics& g, Pen& pen, const RectF& r, REAL radius)
    {
        GraphicsPath path;
        const REAL d = radius * 2.0f;
        path.AddArc(r.X, r.Y, d, d, 180.0f, 90.0f);
        path.AddArc(r.X + r.Width - d, r.Y, d, d, 270.0f, 90.0f);
        path.AddArc(r.X + r.Width - d, r.Y + r.Height - d, d, d, 0.0f, 90.0f);
        path.AddArc(r.X, r.Y + r.Height - d, d, d, 90.0f, 90.0f);
        path.CloseFigure();
        g.DrawPath(&pen, &path);
    }


    void DrawNavIcon(Graphics& g, int index, int x, int y, float progress, bool active)
    {
        const Color ink = active ? C_ACCENT : C_MUTED;
        Pen pen(ink, 1.8f);
        pen.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
        pen.SetLineJoin(LineJoinRound);
        SolidBrush brush(ink);
        GraphicsState saved = g.Save();
        g.SetSmoothingMode(SmoothingModeAntiAlias);

        g.TranslateTransform(static_cast<REAL>(x + 12), static_cast<REAL>(y + 17));
        const REAL p = std::clamp(progress, 0.0f, 1.0f);
        const REAL oneShot = std::sin(p * 3.1415926f);
        switch (index)
        {
        case 0: g.TranslateTransform(0.0f, -2.0f * oneShot); break;
        case 1: g.RotateTransform(4.0f * oneShot); break;
        case 2: g.TranslateTransform(1.5f * oneShot, 0.0f); break;
        case 3: g.RotateTransform(-10.0f * oneShot); break;
        case 4: g.RotateTransform(360.0f * p); break;
        case 5:
        {
            REAL s = 1.0f + 0.10f * oneShot;
            g.ScaleTransform(s, s);
            break;
        }
        case 6:
        {
            REAL s = 1.0f + 0.07f * oneShot;
            g.ScaleTransform(s, s);
            break;
        }
        case 7: g.TranslateTransform(0.0f, -1.5f * oneShot); break;
        case 8: g.TranslateTransform(0.0f, oneShot); break;
        case 9: g.RotateTransform(360.0f * p); break;
        }
        g.TranslateTransform(-12.0f, -12.0f);

        switch (index)
        {
        case 0: // Home
            g.DrawLine(&pen, 3.5f, 11.0f, 12.0f, 4.0f);
            g.DrawLine(&pen, 12.0f, 4.0f, 20.5f, 11.0f);
            g.DrawLine(&pen, 6.0f, 10.0f, 6.0f, 20.0f);
            g.DrawLine(&pen, 18.0f, 10.0f, 18.0f, 20.0f);
            g.DrawLine(&pen, 6.0f, 20.0f, 18.0f, 20.0f);
            g.DrawLine(&pen, 10.0f, 20.0f, 10.0f, 14.0f);
            g.DrawLine(&pen, 10.0f, 14.0f, 14.0f, 14.0f);
            g.DrawLine(&pen, 14.0f, 14.0f, 14.0f, 20.0f);
            break;
        case 1: // Task manager
            DrawRoundOutline(g, pen, RectF(4.0f, 4.0f, 16.0f, 16.0f), 3.0f);
            g.DrawLine(&pen, 7.0f, 8.0f, 10.0f, 8.0f);
            g.DrawLine(&pen, 7.0f, 12.0f, 17.0f, 12.0f);
            g.DrawLine(&pen, 7.0f, 16.0f, 14.0f, 16.0f);
            {
                REAL h = 2.0f + 2.0f * std::sin(p * 6.2831853f);
                g.DrawLine(&pen, 17.0f, 7.0f, 17.0f, 7.0f + h);
            }
            break;
        case 2: // Users
            g.DrawEllipse(&pen, 8.0f, 3.5f, 7.0f, 7.0f);
            g.DrawArc(&pen, 4.5f, 11.0f, 14.0f, 11.0f, 190.0f, 160.0f);
            g.DrawEllipse(&pen, 2.5f + 1.2f * std::sin(p * 6.2831853f), 7.0f, 4.5f, 4.5f);
            g.DrawArc(&pen, 1.0f, 13.0f, 8.0f, 7.0f, 195.0f, 145.0f);
            break;
        case 3: // Diagnostics
            g.DrawEllipse(&pen, 3.5f, 3.5f, 12.5f, 12.5f);
            g.DrawLine(&pen, 14.5f, 14.5f, 21.0f, 21.0f);
            g.DrawLine(&pen, 7.0f, 10.0f, 12.5f, 10.0f);
            g.DrawLine(&pen, 9.75f, 7.25f, 9.75f, 12.75f);
            break;
        case 4: // Recovery
            g.DrawArc(&pen, 3.5f, 3.5f, 17.0f, 17.0f, 42.0f, 285.0f);
            g.DrawLine(&pen, 4.0f, 4.0f, 4.0f, 10.0f);
            g.DrawLine(&pen, 4.0f, 4.0f, 10.0f, 4.0f);
            break;
        case 5: // Cleanup
            DrawRoundOutline(g, pen, RectF(5.0f, 8.0f, 14.0f, 12.0f), 2.0f);
            g.DrawLine(&pen, 4.0f, 6.0f, 20.0f, 6.0f);
            g.DrawLine(&pen, 9.0f, 4.0f, 15.0f, 4.0f);
            g.DrawLine(&pen, 9.0f, 11.0f, 9.0f, 17.0f);
            g.DrawLine(&pen, 15.0f, 11.0f, 15.0f, 17.0f);
            g.DrawLine(&pen, 18.0f, 2.0f, 18.0f, 5.0f);
            g.DrawLine(&pen, 16.5f, 3.5f, 19.5f, 3.5f);
            break;
        case 6: // BSOD / alerts
            {
                GraphicsPath tri;
                tri.AddLine(12.0f, 3.0f, 21.0f, 19.0f);
                tri.AddLine(21.0f, 19.0f, 3.0f, 19.0f);
                tri.AddLine(3.0f, 19.0f, 12.0f, 3.0f);
                tri.CloseFigure();
                g.DrawPath(&pen, &tri);
                g.DrawLine(&pen, 12.0f, 8.0f, 12.0f, 13.0f);
                g.FillEllipse(&brush, 11.1f, 15.0f, 1.8f, 1.8f);
            }
            break;
        case 7: // Registry tree
            g.DrawLine(&pen, 12.0f, 5.0f, 12.0f, 11.0f);
            g.DrawLine(&pen, 5.0f, 11.0f, 19.0f, 11.0f);
            g.DrawLine(&pen, 5.0f, 11.0f, 5.0f, 16.0f);
            g.DrawLine(&pen, 12.0f, 11.0f, 12.0f, 16.0f);
            g.DrawLine(&pen, 19.0f, 11.0f, 19.0f, 16.0f);
            DrawRoundOutline(g, pen, RectF(9.0f, 2.0f, 6.0f, 5.0f), 1.5f);
            DrawRoundOutline(g, pen, RectF(2.0f, 16.0f, 6.0f, 5.0f), 1.5f);
            DrawRoundOutline(g, pen, RectF(9.0f, 16.0f, 6.0f, 5.0f), 1.5f);
            DrawRoundOutline(g, pen, RectF(16.0f, 16.0f, 6.0f, 5.0f), 1.5f);
            break;
        case 8: // Disks
            DrawRoundOutline(g, pen, RectF(3.0f, 4.0f, 18.0f, 6.0f), 2.0f);
            DrawRoundOutline(g, pen, RectF(3.0f, 10.0f, 18.0f, 6.0f), 2.0f);
            DrawRoundOutline(g, pen, RectF(3.0f, 16.0f, 18.0f, 5.0f), 2.0f);
            g.FillEllipse(&brush, 6.0f, 6.0f, 2.0f, 2.0f);
            g.FillEllipse(&brush, 6.0f, 12.0f, 2.0f, 2.0f);
            g.FillEllipse(&brush, 6.0f, 17.5f, 2.0f, 2.0f);
            break;
        case 9: // Settings gear
            {
                GraphicsPath gear;
                const REAL cx = 12.0f, cy = 12.0f;
                REAL previousX = 0.0f;
                REAL previousY = 0.0f;
                for (int i = 0; i < 24; ++i)
                {
                    const REAL a = static_cast<REAL>(i) * 3.1415926f / 12.0f;
                    const REAL r = (i % 3 == 0 || i % 3 == 1) ? 9.0f : 7.2f;
                    const REAL px = cx + std::cos(a) * r;
                    const REAL py = cy + std::sin(a) * r;
                    if (i == 0) gear.StartFigure();
                    else gear.AddLine(previousX, previousY, px, py);
                    previousX = px;
                    previousY = py;
                }
                gear.CloseFigure();
                g.DrawPath(&pen, &gear);
                g.DrawEllipse(&pen, 9.0f, 9.0f, 6.0f, 6.0f);
            }
            break;
        }
        g.Restore(saved);
    }

    void DrawSidebar(Graphics& g, int height)
    {
        Fill(g, MakeRect(0, 0, SIDEBAR_WIDTH, height), C_SIDEBAR);
        Pen border(C_BORDER, 1);
        g.DrawLine(&border, SIDEBAR_WIDTH - 1, 0, SIDEBAR_WIDTH - 1, height);
        DrawBrand(g);

        Text(g, L(language == 0 ? L"РАБОЧЕЕ ПРОСТРАНСТВО" : L"WORKSPACE"),
            22, 91, SIDEBAR_WIDTH - 40, 18, 8, C_FAINT, true);

        const int startY = 120;
        const int itemH = 43;
        for (int i = 0; i < PAGE_COUNT; ++i)
        {
            int y = startY + i * itemH;
            RECT r = MakeRect(12, y, SIDEBAR_WIDTH - 24, 37);
            if (i == currentPage)
            {
                FillRound(g, r, C_ACCENT_SOFT, 8);
                FillRound(g, MakeRect(r.left, r.top + 8, 3, 21), C_ACCENT, 2);
                Pen activeEdge(Color(90, 91, 157, 215), 1.0f);
                g.DrawRectangle(
                    &activeEdge,
                    static_cast<REAL>(r.left + 1),
                    static_cast<REAL>(r.top + 1),
                    static_cast<REAL>(r.right - r.left - 3),
                    static_cast<REAL>(r.bottom - r.top - 3)
                );
            }
            else if (i == hoveredNav)
            {
                FillRound(g, r, C_SURFACE_HOVER, 8);
            }

            const float iconProgress =
                (i == animatedNavPage && animationsEnabled && navIconAnimation < 1.0f)
                ? navIconAnimation : 1.0f;
            DrawNavIcon(g, i, 26, y + 1, iconProgress, i == currentPage);
            Text(g, pageNames[language][i], 58, y + 2, SIDEBAR_WIDTH - 80, 31,
                10, i == currentPage ? C_TEXT : C_MUTED, i == currentPage);
            AddHit(r, HIT_NAV, i);
        }

        const int footerY = height - 66;
        Pen sep(C_BORDER, 1);
        g.DrawLine(&sep, 18, footerY - 10, SIDEBAR_WIDTH - 18, footerY - 10);
        Text(g, L"v1.2.0", 22, footerY, 70, 18, 9, C_MUTED, true);
        Text(g, L(language == 0 ? L"Системные инструменты" : L"System utilities"),
            22, footerY + 20, SIDEBAR_WIDTH - 40, 18, 8, C_FAINT);
    }

    void DrawHeader(Graphics& g, int width)
    {
        Fill(g, MakeRect(SIDEBAR_WIDTH, 0, width - SIDEBAR_WIDTH, HEADER_HEIGHT), C_HEADER);
        Pen p(C_BORDER, 1);
        g.DrawLine(&p, SIDEBAR_WIDTH, HEADER_HEIGHT - 1, width, HEADER_HEIGHT - 1);

        Text(g, pageNames[language][currentPage], SIDEBAR_WIDTH + 28, 13, 480, 30, 18, C_TEXT, true);
        Text(g, pageSubtitles[language][currentPage], SIDEBAR_WIDTH + 29, 44, 650, 20, 9, C_MUTED);

        RECT env = MakeRect(width - 250, 23, 220, 34);
        FillRound(g, env, C_SURFACE, 6);
        Stroke(g, env, C_BORDER);
        FillRound(g, MakeRect(env.left + 10, env.top + 12, 8, 8),
            IsWinRE() ? C_AMBER : C_GREEN, 4);
        Text(g, IsWinRE() ? L"WinRE environment" : L"Windows environment",
            env.left + 26, env.top + 1, env.right - env.left - 34, env.bottom - env.top - 2,
            9, C_MUTED, true);
    }

    void DrawFooter(Graphics& g, int width, int height)
    {
        Fill(g, MakeRect(SIDEBAR_WIDTH, height - FOOTER_HEIGHT,
            width - SIDEBAR_WIDTH, FOOTER_HEIGHT), C_HEADER);
        Pen p(C_BORDER, 1);
        g.DrawLine(&p, SIDEBAR_WIDTH, height - FOOTER_HEIGHT, width, height - FOOTER_HEIGHT);
        Text(g, statusText, SIDEBAR_WIDTH + 24, height - FOOTER_HEIGHT + 2,
            width - SIDEBAR_WIDTH - 260, FOOTER_HEIGHT - 4, 8, C_MUTED);
        Text(g, L"UNLOCKTOOL", width - 150, height - FOOTER_HEIGHT + 2,
            120, FOOTER_HEIGHT - 4, 8, C_FAINT, true);
    }

    void DrawMetric(Graphics& g, int x, int y, int w, int h,
        const std::wstring& label, const std::wstring& value,
        const std::wstring& detail, float ratio, const Color& accent)
    {
        RECT r = MakeRect(x, y, w, h);
        DrawPanel(g, r);
        Text(g, label, x + 16, y + 12, w - 32, 20, 9, C_MUTED, true);
        Text(g, value, x + 16, y + 38, w - 32, 36, 23, C_TEXT, true);
        Text(g, detail, x + 16, y + 78, w - 32, 20, 8, C_FAINT);
        RECT track = MakeRect(x + 16, y + h - 20, w - 32, 5);
        FillRound(g, track, C_BORDER, 3);
        int fillWidth = static_cast<int>((w - 32) * (std::max)(0.0f, (std::min)(ratio, 1.0f)));
        if (fillWidth > 0) FillRound(g, MakeRect(track.left, track.top, fillWidth, 5), accent, 3);
    }

    void DrawHome(Graphics& g, int x, int y, int width, int height)
    {
        MEMORYSTATUSEX mem{}; mem.dwLength = sizeof(mem);
        GlobalMemoryStatusEx(&mem);
        SYSTEM_INFO si{}; GetSystemInfo(&si);
        ULARGE_INTEGER freeBytes{}, totalBytes{};
        GetDiskFreeSpaceExW(L"C:\\", &freeBytes, &totalBytes, nullptr);
        const double memUsed = 100.0 - static_cast<double>(mem.ullAvailPhys) * 100.0 /
            (std::max)(1.0, static_cast<double>(mem.ullTotalPhys));
        const double diskUsed = totalBytes.QuadPart
            ? 100.0 - static_cast<double>(freeBytes.QuadPart) * 100.0 / totalBytes.QuadPart : 0.0;

        Text(g, L(language == 0 ? L"Обзор системы" : L"System overview"),
            x, y, width, 28, 13, C_TEXT, true);
        Text(g, L(language == 0 ? L"Ключевые показатели текущего сеанса Windows"
                                : L"Key indicators for the current Windows session"),
            x, y + 28, width, 20, 9, C_MUTED);

        int gap = 14;
        int cardW = (width - gap * 3) / 4;
        DrawMetric(g, x, y + 62, cardW, 128,
            L"PROCESSOR", std::to_wstring(si.dwNumberOfProcessors) + L" " +
                L(language == 0 ? L"ядер" : L"cores"),
            L(language == 0 ? L"Логические процессоры" : L"Logical processors"),
            0.0f, C_ACCENT);
        DrawMetric(g, x + cardW + gap, y + 62, cardW, 128,
            L"MEMORY", FormatBytes(mem.ullAvailPhys) + L" " + L(language == 0 ? L"свободно" : L"free"),
            FormatBytes(mem.ullTotalPhys) + L" total", static_cast<float>(memUsed / 100.0), C_GREEN);
        DrawMetric(g, x + (cardW + gap) * 2, y + 62, cardW, 128,
            L"SYSTEM DRIVE", FormatBytes(freeBytes.QuadPart) + L" " + L(language == 0 ? L"свободно" : L"free"),
            FormatBytes(totalBytes.QuadPart) + L" total", static_cast<float>(diskUsed / 100.0), C_AMBER);
        DrawMetric(g, x + (cardW + gap) * 3, y + 62, cardW, 128,
            L"PROCESSES", std::to_wstring(processes.size()),
            L(language == 0 ? L"Обнаружено процессов" : L"Processes detected"),
            0.0f, C_ACCENT);

        int lowerY = y + 210;
        int leftW = (width - gap) * 58 / 100;
        RECT quick = MakeRect(x, lowerY, leftW, height - (lowerY - y));
        DrawPanel(g, quick);
        Text(g, L(language == 0 ? L"Быстрый доступ" : L"Quick access"),
            quick.left + 16, quick.top + 10, leftW - 32, 25, 11, C_TEXT, true);
        int bw = (leftW - 48) / 2;
        Button(g, quick.left + 16, quick.top + 52, bw, 38,
            L(language == 0 ? L"Диспетчер задач" : L"Task Manager"), HIT_NAV, PAGE_TASKS);
        Button(g, quick.left + 24 + bw, quick.top + 52, bw, 38,
            L(language == 0 ? L"Диагностика" : L"Diagnostics"), HIT_NAV, PAGE_DIAGNOSTICS);
        Button(g, quick.left + 16, quick.top + 100, bw, 38,
            L(language == 0 ? L"Очистка системы" : L"System cleanup"), HIT_NAV, PAGE_CLEANUP);
        Button(g, quick.left + 24 + bw, quick.top + 100, bw, 38,
            L(language == 0 ? L"Восстановление" : L"Recovery"), HIT_NAV, PAGE_RECOVERY);

        int rightX = x + leftW + gap;
        int rightW = width - leftW - gap;
        RECT state = MakeRect(rightX, lowerY, rightW, height - (lowerY - y));
        DrawPanel(g, state);
        Text(g, L(language == 0 ? L"Состояние среды" : L"Environment"),
            state.left + 16, state.top + 10, rightW - 32, 25, 11, C_TEXT, true);
        Text(g, IsWinRE() ? L"Windows Recovery Environment" : L"Windows desktop session",
            state.left + 16, state.top + 48, rightW - 32, 22, 9, C_TEXT);
        Text(g, L(language == 0 ? L"Проверка обновлений" : L"Update status"),
            state.left + 16, state.top + 82, rightW - 32, 18, 8, C_MUTED);
        Button(g, state.left + 16, state.top + 110, rightW - 32, 34,
            L(language == 0 ? L"Проверить обновления UnlockTool" : L"Check UnlockTool updates"),
            HIT_SETTING_UPDATE, 0, true);
    }

    void DrawTableHeader(Graphics& g, int x, int y, int w,
        const std::vector<std::pair<std::wstring,int>>& cols)
    {
        Fill(g, MakeRect(x, y, w, 30), Color(255, 31, 45, 59));
        int cx = x;
        for (const auto& c : cols)
        {
            Text(g, c.first, cx + 10, y, c.second - 12, 30, 8, C_MUTED, true);
            cx += c.second;
        }
    }

    void DrawTasks(Graphics& g, int x, int y, int width, int height)
    {
        const int buttonY = y;
        Button(g, x, buttonY, 112, 34, L(language == 0 ? L"Обновить" : L"Refresh"),
            HIT_TASK_REFRESH, 0, true);
        Button(g, x + 122, buttonY, 145, 34, L(language == 0 ? L"Автозагрузка" : L"Startup apps"),
            HIT_TASK_STARTUP);
        Button(g, x + width - 350, buttonY, 108, 34,
            L(language == 0 ? L"Завершить" : L"End task"), HIT_TASK_END,
            0, false, selectedTask < 0);
        Button(g, x + width - 232, buttonY, 108, 34,
            L(language == 0 ? L"Пауза" : L"Suspend"), HIT_TASK_SUSPEND,
            0, false, selectedTask < 0);
        Button(g, x + width - 114, buttonY, 108, 34,
            L(language == 0 ? L"Продолжить" : L"Resume"), HIT_TASK_RESUME,
            0, false, selectedTask < 0);

        RECT search = MakeRect(x, y + 48, width, 34);
        FillRound(g, search, C_SURFACE, 6);
        Stroke(g, search, processSearchFocused ? C_ACCENT : C_BORDER);
        Text(g, (processSearch.empty()
            ? L(language == 0 ? L"Поиск по имени процесса или PID..." : L"Search process name or PID...")
            : processSearch), search.left + 12, search.top, search.right - search.left - 24, 34,
            9, processSearch.empty() ? C_FAINT : C_TEXT);
        Text(g, L(language == 0 ? L"Нажмите здесь и начните ввод" : L"Click here and type"),
            search.right - 190, search.top, 178, 34, 8, C_FAINT);
        if (processSearchFocused) Stroke(g, search, C_ACCENT);
        // Search input is handled by WM_CHAR while this region is focused.
        AddHit(search, HIT_NONE, 0);

        int tableY = y + 96;
        int tableH = height - 100;
        RECT table = MakeRect(x, tableY, width, tableH);
        DrawPanel(g, table);
        const int cols[] = { width * 34 / 100, width * 12 / 100,
            width * 16 / 100, width * 18 / 100, width * 20 / 100 };
        DrawTableHeader(g, x + 1, tableY + 1, width - 2,
            { {L(language == 0 ? L"ПРОЦЕСС" : L"PROCESS"),cols[0]},
              {L"PID",cols[1]},
              {L"CPU",cols[2]},
              {L"RAM",cols[3]},
              {L(language == 0 ? L"СОСТОЯНИЕ" : L"STATE"),cols[4]} });

        auto filtered = TaskManager::SearchProcesses(processes, processSearch);
        const int rowH = 31;
        const int visible = (std::max)(1, (tableH - 34) / rowH);
        const int maxScroll = (std::max)(0, static_cast<int>(filtered.size()) - visible);
        taskScroll = (std::min)(taskScroll, maxScroll);
        for (int row = 0; row < visible && row + taskScroll < static_cast<int>(filtered.size()); ++row)
        {
            const auto& p = filtered[row + taskScroll];
            const int yy = tableY + 31 + row * rowH;
            RECT rr = MakeRect(x + 1, yy, width - 2, rowH);
            const int originalIndex = static_cast<int>(&p - filtered.data());
            const bool isSelected = selectedTask >= 0 &&
                selectedTask < static_cast<int>(processes.size()) &&
                processes[selectedTask].pid == p.pid;
            if (isSelected) Fill(g, rr, C_ACCENT_SOFT);
            else if (row % 2 == 1) Fill(g, rr, Color(255, 26, 38, 51));

            int cx = x;
            Text(g, p.name, cx + 12, yy, cols[0] - 18, rowH, 9, C_TEXT, isSelected);
            cx += cols[0];
            Text(g, std::to_wstring(p.pid), cx + 10, yy, cols[1] - 16, rowH, 8, C_MUTED);
            cx += cols[1];
            Text(g, p.cpuAvailable ? std::to_wstring(p.cpuUsage).substr(0, 5) + L"%" : L"—",
                cx + 10, yy, cols[2] - 16, rowH, 8, C_MUTED);
            cx += cols[2];
            Text(g, p.memoryAvailable ? FormatBytes(p.memoryUsage) : L"—",
                cx + 10, yy, cols[3] - 16, rowH, 8, C_MUTED);
            cx += cols[3];
            std::wstring state = p.isCritical ? L"Critical" :
                p.isSuspended ? L"Suspended" :
                p.isResponding ? L"Running" : L"Not responding";
            Text(g, state, cx + 10, yy, cols[4] - 16, rowH, 8,
                p.isCritical ? C_AMBER : p.isResponding ? C_GREEN : C_RED);
            AddHit(rr, HIT_TASK_ROW, static_cast<int>(p.pid));
            (void)originalIndex;
        }
        Text(g, L(language == 0 ? L"Процессов: " : L"Processes: ") +
            std::to_wstring(filtered.size()), x + 12, tableY + tableH - 22, 180, 18, 8, C_FAINT);
    }

    void DrawCleanup(Graphics& g, int x, int y, int width, int height)
    {
        Text(g, L(language == 0 ? L"Выберите категории для анализа" : L"Select categories to analyze"),
            x, y, width, 24, 12, C_TEXT, true);
        Text(g, L(language == 0 ? L"Сканирование оценивает объём данных до подтверждённого удаления."
                                : L"Scanning estimates data size before a separately confirmed cleanup."),
            x, y + 26, width, 20, 9, C_MUTED);
        Button(g, x, y + 58, 142, 36, L(language == 0 ? L"Сканировать" : L"Scan"),
            HIT_CLEANUP_SCAN, 0, true, cleanupRunning);
        Button(g, x + 152, y + 58, 170, 36, L(language == 0 ? L"Очистить выбранное" : L"Clean selected"),
            HIT_CLEANUP_RUN, 0, false, cleanupRunning);
        int cardY = y + 112;
        int gap = 12;
        int cardW = (width - gap) / 2;
        for (int i = 0; i < static_cast<int>(cleanupItems.size()) && i < 4; ++i)
        {
            const auto& item = cleanupItems[i];
            int col = i % 2, row = i / 2;
            RECT r = MakeRect(x + col * (cardW + gap), cardY + row * 106, cardW, 92);
            DrawPanel(g, r);
            RECT check = MakeRect(r.left + 15, r.top + 17, 18, 18);
            FillRound(g, check, item.selected ? C_ACCENT : C_SURFACE_2, 4);
            if (item.selected) Text(g, L"✓", check.left, check.top - 1, 18, 18, 11, C_TEXT, true);
            Text(g, item.name, r.left + 45, r.top + 10, cardW - 60, 24, 10, C_TEXT, true);
            Text(g, item.description, r.left + 45, r.top + 36, cardW - 60, 18, 8, C_MUTED);
            std::wstring stat = item.scanned
                ? FormatBytes(item.size) + L"  •  " + std::to_wstring(item.filesCount) + L" files"
                : L(language == 0 ? L"Не сканировано" : L"Not scanned");
            Text(g, stat, r.left + 45, r.top + 60, cardW - 60, 18, 8, item.scanned ? C_GREEN : C_FAINT);
            AddHit(r, HIT_CLEANUP_TOGGLE, i);
        }
        if (cleanupRunning)
            Text(g, L(language == 0 ? L"Операция выполняется в фоновом потоке..." : L"Operation is running in background..."),
                x, cardY + 220, width, 22, 9, C_AMBER, true);
    }

    void DrawUsers(Graphics& g, int x, int y, int width, int height)
    {
        Button(g, x, y, 112, 34, L(language == 0 ? L"Обновить" : L"Refresh"), HIT_USER_REFRESH, 0, true);
        Button(g, x + 122, y, 142, 34, L(language == 0 ? L"Создать" : L"Create user"), HIT_USER_CREATE);
        Button(g, x + width - 360, y, 108, 34, L(language == 0 ? L"Включить" : L"Enable"), HIT_USER_ENABLE, 0, false, selectedUser < 0);
        Button(g, x + width - 242, y, 108, 34, L(language == 0 ? L"Отключить" : L"Disable"), HIT_USER_DISABLE, 0, false, selectedUser < 0);
        Button(g, x + width - 124, y, 108, 34, L(language == 0 ? L"Удалить" : L"Delete"), HIT_USER_DELETE, 0, false, selectedUser < 0);
        RECT table = MakeRect(x, y + 50, width, height - 50);
        DrawPanel(g, table);
        DrawTableHeader(g, x + 1, y + 51, width - 2,
            { {L(language == 0 ? L"ИМЯ ПОЛЬЗОВАТЕЛЯ" : L"USERNAME"), width * 30 / 100},
              {L(language == 0 ? L"ПОЛНОЕ ИМЯ" : L"FULL NAME"), width * 34 / 100},
              {L(language == 0 ? L"СТАТУС" : L"STATUS"), width * 18 / 100},
              {L(language == 0 ? L"ПРИВИЛЕГИИ" : L"PRIVILEGE"), width * 18 / 100} });
        const int rowH = 36;
        for (int i = 0; i < static_cast<int>(users.size()); ++i)
        {
            int yy = y + 82 + i * rowH;
            if (yy + rowH > y + height - 4) break;
            RECT r = MakeRect(x + 1, yy, width - 2, rowH);
            if (i == selectedUser) Fill(g, r, C_ACCENT_SOFT);
            else if (i % 2) Fill(g, r, Color(255, 26, 38, 51));
            int c1 = width * 30 / 100, c2 = width * 34 / 100, c3 = width * 18 / 100;
            Text(g, users[i].username, x + 12, yy, c1 - 18, rowH, 9, C_TEXT, i == selectedUser);
            Text(g, users[i].fullName, x + c1 + 10, yy, c2 - 18, rowH, 9, C_MUTED);
            Text(g, users[i].disabled ? L"Disabled" : L"Enabled",
                x + c1 + c2 + 10, yy, c3 - 18, rowH, 8, users[i].disabled ? C_AMBER : C_GREEN);
            Text(g, users[i].privilege == USER_PRIV_ADMIN ? L"Administrator" : L"Standard",
                x + c1 + c2 + c3 + 10, yy, width - c1 - c2 - c3 - 18, rowH, 8, C_MUTED);
            AddHit(r, HIT_USER_ROW, i);
        }
        Button(g, x, y + height - 42, 160, 32,
            L(language == 0 ? L"Изменить пароль" : L"Change password"),
            HIT_USER_PASSWORD, 0, false, selectedUser < 0);
    }

    void DrawDiagnostics(Graphics& g, int x, int y, int width, int height)
    {
        int gap = 12;
        int cw = (width - gap * 2) / 3;
        auto toolCard = [&](int idx, const std::wstring& title, const std::wstring& desc, Hit hit)
        {
            int xx = x + idx * (cw + gap);
            RECT r = MakeRect(xx, y, cw, 112);
            DrawPanel(g, r);
            Text(g, title, xx + 14, y + 12, cw - 28, 24, 10, C_TEXT, true);
            Text(g, desc, xx + 14, y + 40, cw - 28, 35, 8, C_MUTED);
            Button(g, xx + 14, y + 78, cw - 28, 25,
                L(language == 0 ? L"Запустить" : L"Launch"), hit, 0, false);
        };
        toolCard(0, L"System Information", L(language == 0 ? L"Сведения об оборудовании и ОС" : L"Hardware and OS details"), HIT_DIAG_SYSTEM);
        toolCard(1, L"SFC Verify", L(language == 0 ? L"Проверка целостности системных файлов" : L"Verify protected system files"), HIT_DIAG_SFC);
        toolCard(2, L"Services", L(language == 0 ? L"Управление службами Windows" : L"Windows service console"), HIT_DIAG_SERVICES);

        int panelY = y + 130;
        RECT panel = MakeRect(x, panelY, width, height - 130);
        DrawPanel(g, panel);
        Text(g, L"IFEO Debugger Detector", x + 16, panelY + 10, width - 32, 24, 11, C_TEXT, true);
        Text(g, L(language == 0 ? L"Зарегистрированные отладчики для исполняемых файлов"
                                : L"Registered image execution option debugger entries"),
            x + 16, panelY + 36, width - 32, 18, 8, C_MUTED);
        Button(g, x + width - 154, panelY + 10, 138, 30,
            L(language == 0 ? L"Сканировать" : L"Scan"), HIT_DIAG_DEBUG_SCAN, 0, true);
        int rowY = panelY + 64;
        for (int i = 0; i < static_cast<int>(debuggerEntries.size()) && i < 5; ++i)
        {
            RECT r = MakeRect(x + 12, rowY + i * 34, width - 24, 30);
            if (i == selectedDebugger) Fill(g, r, C_ACCENT_SOFT);
            else Fill(g, r, Color(255, 27, 39, 52));
            Text(g, debuggerEntries[i].imageName, r.left + 10, r.top, width * 30 / 100, 30, 8, C_TEXT, true);
            Text(g, debuggerEntries[i].debuggerPath, r.left + width * 30 / 100, r.top,
                width * 55 / 100, 30, 8, C_MUTED);
            AddHit(r, HIT_DEBUG_ROW, i);
        }
        if (debuggerEntries.empty())
            Text(g, L(language == 0 ? L"Записи не найдены или сканирование ещё не запускалось."
                                    : L"No entries found, or scan has not been run yet."),
                x + 18, rowY + 4, width - 36, 28, 9, C_FAINT);
        Button(g, x + 16, panelY + height - 46, 180, 30,
            L(language == 0 ? L"Удалить выбранную запись" : L"Remove selected entry"),
            HIT_DEBUG_REMOVE, 0, false, selectedDebugger < 0);
    }

    void DrawRecovery(Graphics& g, int x, int y, int width, int height)
    {
        Text(g, L(language == 0 ? L"Средства восстановления Windows" : L"Windows recovery tools"),
            x, y, width, 25, 12, C_TEXT, true);
        Text(g, IsWinRE()
            ? L(language == 0 ? L"Обнаружена среда WinRE. Некоторые операции могут быть недоступны."
                              : L"WinRE detected. Some operations may be unavailable.")
            : L(language == 0 ? L"Команды запускаются с повышенными правами и требуют подтверждения."
                              : L"Commands launch elevated and require confirmation."),
            x, y + 27, width, 20, 9, IsWinRE() ? C_AMBER : C_MUTED);
        int gap = 12, cw = (width - gap * 2) / 3, ch = 100;
        auto recoveryCard = [&](int idx, const std::wstring& title, const std::wstring& desc, Hit hit)
        {
            int xx = x + (idx % 3) * (cw + gap);
            int yy = y + 62 + (idx / 3) * (ch + gap);
            RECT r = MakeRect(xx, yy, cw, ch);
            DrawPanel(g, r);
            Text(g, title, xx + 14, yy + 10, cw - 28, 24, 10, C_TEXT, true);
            Text(g, desc, xx + 14, yy + 36, cw - 28, 28, 8, C_MUTED);
            Button(g, xx + 14, yy + 68, cw - 28, 24,
                L(language == 0 ? L"Запустить" : L"Run"), hit, 0, false,
            (IsWinRE() && idx != 3) || (idx == 5 && bootRunning));
        };
        recoveryCard(0, L"SFC /scannow", L(language == 0 ? L"Проверка и восстановление файлов" : L"Verify and repair system files"), HIT_RECOVERY_SFC);
        recoveryCard(1, L"DISM RestoreHealth", L(language == 0 ? L"Восстановление хранилища компонентов" : L"Repair component store"), HIT_RECOVERY_DISM);
        recoveryCard(2, L"CHKDSK", L(language == 0 ? L"Проверка тома C: без перезагрузки" : L"Scan volume C: online"), HIT_RECOVERY_CHKDSK);
        recoveryCard(3, L"Windows RE", L(language == 0 ? L"Переход в дополнительные параметры запуска" : L"Restart to advanced startup"), HIT_RECOVERY_WINRE);
        recoveryCard(4, L"Enable UAC", L(language == 0 ? L"Включить контроль учётных записей" : L"Enable User Account Control"), HIT_RECOVERY_UAC);
        recoveryCard(5, L"Bootloader Repair", L(language == 0 ? L"Восстановление загрузочных файлов BCDBoot" : L"Repair boot files with BCDBoot"), HIT_RECOVERY_BOOT);
    }

    void DrawBsod(Graphics& g, int x, int y, int width, int height)
    {
        Button(g, x, y, 110, 34, L(language == 0 ? L"Обновить" : L"Refresh"), HIT_BSOD_REFRESH, 0, true);
        Button(g, x + 120, y, 130, 34, L(language == 0 ? L"Минидампы" : L"Minidumps"), HIT_BSOD_DUMPS);
        Button(g, x + 260, y, 140, 34, L"Event Viewer", HIT_BSOD_EVENT);
        Button(g, x + 410, y, 150, 34, L"Reliability Monitor", HIT_BSOD_RELIABILITY);
        Button(g, x + 570, y, 150, 34, L(language == 0 ? L"Экспорт отчётов" : L"Export reports"), HIT_BSOD_EXPORT);
        RECT panel = MakeRect(x, y + 48, width, height - 48);
        DrawPanel(g, panel);
        Text(g, L(language == 0 ? L"СИСТЕМНЫЕ ИНЦИДЕНТЫ" : L"SYSTEM INCIDENTS"),
            x + 14, y + 54, width - 28, 26, 8, C_MUTED, true);
        DrawTableHeader(g, x + 1, y + 82, width - 2,
            { {L(language == 0 ? L"ВРЕМЯ" : L"TIME"), width * 26 / 100},
              {L"BUGCHECK", width * 20 / 100},
              {L"PROVIDER", width * 24 / 100},
              {L(language == 0 ? L"ПОДРОБНОСТИ" : L"DETAILS"), width * 30 / 100} });
        int rowH = 34;
        for (int i = 0; i < static_cast<int>(incidents.size()) && i < 8; ++i)
        {
            int yy = y + 112 + i * rowH;
            RECT r = MakeRect(x + 1, yy, width - 2, rowH);
            if (i == selectedIncident) Fill(g, r, C_ACCENT_SOFT);
            else if (i % 2) Fill(g, r, Color(255, 26, 38, 51));
            int c1 = width * 26 / 100, c2 = width * 20 / 100, c3 = width * 24 / 100;
            Text(g, incidents[i].timestamp, x + 12, yy, c1 - 18, rowH, 8, C_MUTED);
            Text(g, incidents[i].bugcheckCode, x + c1 + 8, yy, c2 - 16, rowH, 8, C_AMBER, true);
            Text(g, incidents[i].provider, x + c1 + c2 + 8, yy, c3 - 16, rowH, 8, C_MUTED);
            Text(g, incidents[i].details, x + c1 + c2 + c3 + 8, yy,
                width - c1 - c2 - c3 - 18, rowH, 8, C_FAINT);
            AddHit(r, HIT_BSOD_ROW, i);
        }
        if (incidents.empty())
            Text(g, L(language == 0 ? L"Записи BugCheck не найдены." : L"No BugCheck incidents found."),
                x + 18, y + 132, width - 36, 28, 9, C_FAINT);
    }

    void DrawRegistry(Graphics& g, int x, int y, int width, int height)
    {
        Button(g, x, y, 120, 34, L(language == 0 ? L"Проверить" : L"Refresh"), HIT_REGISTRY_REFRESH, 0, true);
        Button(g, x + 132, y, 200, 34, L(language == 0 ? L"Восстановить выбранное" : L"Restore selected"),
            HIT_REGISTRY_RESTORE, 0, false, selectedRegistry < 0);
        Button(g, x + 344, y, 190, 34, L(language == 0 ? L"Изменить значение" : L"Edit value"),
            HIT_REGISTRY_EDIT, 0, false, selectedRegistry < 0);
        RECT panel = MakeRect(x, y + 48, width, height - 48);
        DrawPanel(g, panel);
        Text(g, L(language == 0 ? L"КРИТИЧЕСКИЕ ПАРАМЕТРЫ WINDOWS" : L"CRITICAL WINDOWS PARAMETERS"),
            x + 14, y + 54, width - 28, 26, 8, C_MUTED, true);
        DrawTableHeader(g, x + 1, y + 82, width - 2,
            { {L(language == 0 ? L"ПАРАМЕТР" : L"PARAMETER"), width * 22 / 100},
              {L(language == 0 ? L"ТЕКУЩЕЕ ЗНАЧЕНИЕ" : L"CURRENT VALUE"), width * 39 / 100},
              {L(language == 0 ? L"ОЖИДАЕМОЕ" : L"EXPECTED"), width * 29 / 100},
              {L(language == 0 ? L"СТАТУС" : L"STATUS"), width * 10 / 100} });
        int rowH = 42;
        for (int i = 0; i < static_cast<int>(registryItems.size()); ++i)
        {
            int yy = y + 112 + i * rowH;
            if (yy + rowH > y + height - 4) break;
            const auto& p = registryItems[i];
            RECT r = MakeRect(x + 1, yy, width - 2, rowH);
            if (i == selectedRegistry) Fill(g, r, C_ACCENT_SOFT);
            else if (i % 2) Fill(g, r, Color(255, 26, 38, 51));
            Text(g, p.name, x + 12, yy, width * 22 / 100 - 18, rowH, 8, C_TEXT, true);
            Text(g, p.readable ? p.currentValue : L(language == 0 ? L"Недоступно" : L"Unavailable"),
                x + width * 22 / 100 + 8, yy, width * 39 / 100 - 16, rowH, 8, C_MUTED);
            Text(g, p.expectedValue, x + width * 61 / 100 + 8, yy, width * 29 / 100 - 16, rowH, 8, C_FAINT);
            Text(g, p.matchesExpected ? L"OK" : L"CHECK",
                x + width * 90 / 100 + 6, yy, width * 10 / 100 - 10, rowH, 8,
                p.matchesExpected ? C_GREEN : C_AMBER, true);
            AddHit(r, HIT_REGISTRY_ROW, i);
        }
    }

    void DrawDisks(Graphics& g, int x, int y, int width, int height)
    {
        Button(g, x, y, 112, 34, L(language == 0 ? L"Обновить" : L"Refresh"), HIT_DISK_ROW, -1, true);
        Button(g, x + 122, y, 140, 34, L(language == 0 ? L"Управление дисками" : L"Disk Management"),
            HIT_DISK_MANAGEMENT);
        Button(g, x + width - 380, y, 110, 34, L(language == 0 ? L"Открыть" : L"Open"),
            HIT_DISK_OPEN, 0, false, selectedDisk < 0);
        Button(g, x + width - 260, y, 110, 34, L(language == 0 ? L"Проверить" : L"Scan"),
            HIT_DISK_SCAN, 0, false, selectedDisk < 0);
        Button(g, x + width - 140, y, 124, 34, L"BitLocker",
            HIT_DISK_BITLOCKER, 0, false, selectedDisk < 0);

        RECT panel = MakeRect(x, y + 48, width, height - 48);
        DrawPanel(g, panel);
        Text(g, L(language == 0 ? L"ТОМА И РАЗДЕЛЫ" : L"VOLUMES AND PARTITIONS"),
            x + 14, y + 54, width - 28, 26, 8, C_MUTED, true);
        DrawTableHeader(g, x + 1, y + 82, width - 2,
            { {L(language == 0 ? L"ТОМ" : L"VOLUME"), width * 12 / 100},
              {L(language == 0 ? L"МЕТКА / МОДЕЛЬ" : L"LABEL / MODEL"), width * 25 / 100},
              {L"FILE SYSTEM", width * 14 / 100},
              {L(language == 0 ? L"ОБЪЁМ" : L"CAPACITY"), width * 17 / 100},
              {L(language == 0 ? L"СВОБОДНО" : L"FREE"), width * 17 / 100},
              {L(language == 0 ? L"СОСТОЯНИЕ" : L"STATUS"), width * 15 / 100} });
        int rowH = 42;
        for (int i = 0; i < static_cast<int>(disks.size()); ++i)
        {
            int yy = y + 112 + i * rowH;
            if (yy + rowH > y + height - 4) break;
            const auto& d = disks[i];
            RECT r = MakeRect(x + 1, yy, width - 2, rowH);
            if (i == selectedDisk) Fill(g, r, C_ACCENT_SOFT);
            else if (i % 2) Fill(g, r, Color(255, 26, 38, 51));
            int c1 = width * 12 / 100, c2 = width * 25 / 100, c3 = width * 14 / 100;
            int c4 = width * 17 / 100, c5 = width * 17 / 100;
            Text(g, d.root, x + 12, yy, c1 - 18, rowH, 9, C_TEXT, true);
            Text(g, d.label.empty() ? d.model : d.label, x + c1 + 8, yy, c2 - 16, rowH, 8, C_MUTED);
            Text(g, d.fileSystem, x + c1 + c2 + 8, yy, c3 - 16, rowH, 8, C_MUTED);
            Text(g, FormatBytes(d.totalBytes), x + c1 + c2 + c3 + 8, yy, c4 - 16, rowH, 8, C_MUTED);
            Text(g, FormatBytes(d.freeBytes), x + c1 + c2 + c3 + c4 + 8, yy, c5 - 16, rowH, 8, C_MUTED);
            Text(g, d.ready ? L"Ready" : L"Unavailable",
                x + c1 + c2 + c3 + c4 + c5 + 8, yy,
                width - c1 - c2 - c3 - c4 - c5 - 16, rowH, 8, d.ready ? C_GREEN : C_AMBER);
            AddHit(r, HIT_DISK_ROW, i);
        }
    }

    void DrawSettings(Graphics& g, int x, int y, int width, int height)
    {
        // Keep the settings rows inside their panel and align all action buttons
        // to the same right-hand column. The content area is at least 500 px high
        // at the window's minimum tracking size.
        const int generalHeight = 270;
        RECT general = MakeRect(x, y, width, generalHeight);
        DrawPanel(g, general);
        Text(g, L(language == 0 ? L"ОСНОВНЫЕ ПАРАМЕТРЫ" : L"GENERAL PREFERENCES"),
            x + 16, y + 10, width - 32, 25, 9, C_MUTED, true);

        const int actionWidth = 126;
        const int actionRight = x + width - 22;
        const int actionLeft = actionRight - actionWidth;
        auto settingRow = [&](int row, const std::wstring& title, const std::wstring& desc,
            const std::wstring& state, Hit hit, bool enabled)
        {
            const int yy = y + 45 + row * 43;
            const int textWidth = (std::max)(180, actionLeft - (x + 34) - 18);
            Text(g, title, x + 18, yy, textWidth, 19, 9, C_TEXT, true);
            Text(g, desc, x + 18, yy + 19, textWidth, 16, 8, C_MUTED);
            RECT toggle = MakeRect(actionLeft, yy + 3, actionWidth, 28);
            FillRound(g, toggle, enabled ? C_ACCENT_SOFT : C_SURFACE_2, 5);
            DrawLabel(g, state, toggle, 8, enabled ? C_TEXT : C_MUTED,
                true, StringAlignmentCenter);
            AddHit(toggle, hit);
        };

        settingRow(0, L(language == 0 ? L"Язык интерфейса" : L"Interface language"),
            L(language == 0 ? L"Переключение RU / EN" : L"Switch between Russian and English"),
            language == 0 ? L"РУССКИЙ" : L"ENGLISH", HIT_SETTING_LANGUAGE, true);
        settingRow(1, L(language == 0 ? L"Автопроверка обновлений" : L"Automatic update checks"),
            L(language == 0 ? L"Проверять релизы при запуске" : L"Check releases when the app starts"),
            autoCheckUpdates ? L"ON" : L"OFF", HIT_SETTING_AUTOCHECK, autoCheckUpdates);
        settingRow(2, L(language == 0 ? L"Автозапуск" : L"Start with Windows"),
            L(language == 0 ? L"Добавить UnlockTool в Run текущего пользователя" : L"Add UnlockTool to current-user Run key"),
            autoStartEnabled ? L"ON" : L"OFF", HIT_SETTING_AUTOSTART, autoStartEnabled);
        settingRow(3, L(language == 0 ? L"Уведомления" : L"Notifications"),
            L(language == 0 ? L"Разрешить уведомления приложения" : L"Allow application notifications"),
            notificationsEnabled ? L"ON" : L"OFF", HIT_SETTING_NOTIFICATIONS, notificationsEnabled);
        settingRow(4, L(language == 0 ? L"Анимации" : L"Animations"),
            L(language == 0 ? L"Плавные переходы и эффекты наведения" : L"Page transitions and hover effects"),
            animationsEnabled ? L"ON" : L"OFF", HIT_SETTING_ANIMATIONS, animationsEnabled);

        const int maintenanceY = y + generalHeight + 14;
        const int maintenanceHeight = (std::max)(150, height - generalHeight - 14);
        RECT maintenance = MakeRect(x, maintenanceY, width, maintenanceHeight);
        DrawPanel(g, maintenance);
        Text(g, L(language == 0 ? L"ОБСЛУЖИВАНИЕ ПРИЛОЖЕНИЯ" : L"APPLICATION MAINTENANCE"),
            x + 16, maintenance.top + 10, width - 32, 25, 9, C_MUTED, true);

        const int buttonX = actionRight - 180;
        const int leftTextWidth = (std::max)(180, buttonX - (x + 18) - 18);
        Text(g, L(language == 0 ? L"Восстановить стандартную тему Windows и сглаживание шрифтов"
                                : L"Restore the default Windows theme and font smoothing"),
            x + 18, maintenance.top + 48, leftTextWidth, 34, 9, C_TEXT);
        Button(g, buttonX, maintenance.top + 46, 180, 34,
            L(language == 0 ? L"Восстановить оформление" : L"Restore appearance"),
            HIT_SETTING_APPEARANCE);

        Text(g, L(language == 0 ? L"Версия UnlockTool 1.2.0 • C++ / Win32 API / GDI+"
                                : L"UnlockTool 1.2.0 • C++ / Win32 API / GDI+"),
            x + 18, maintenance.top + 94, leftTextWidth, 22, 8, C_MUTED);
        Button(g, buttonX, maintenance.top + 122, 180, 34,
            L(language == 0 ? L"Проверить обновления" : L"Check for updates"),
            HIT_SETTING_UPDATE, 0, true);
    }

    void DrawContent(Graphics& g, int width, int height)
    {
        const int x = SIDEBAR_WIDTH + 28;
        const int y = HEADER_HEIGHT + 22;
        const int w = width - x - 28;
        const int h = height - HEADER_HEIGHT - FOOTER_HEIGHT - 42;
        if (w <= 0 || h <= 0) return;

        GraphicsState state = g.Save();
        if (animationsEnabled && pageTransition < 1.0f)
        {
            const float t = pageTransition;
            const float eased = 1.0f - (1.0f - t) * (1.0f - t);
            g.TranslateTransform((1.0f - eased) * 22.0f, 0.0f);
        }

        switch (currentPage)
        {
        case PAGE_HOME: DrawHome(g, x, y, w, h); break;
        case PAGE_TASKS: DrawTasks(g, x, y, w, h); break;
        case PAGE_USERS: DrawUsers(g, x, y, w, h); break;
        case PAGE_DIAGNOSTICS: DrawDiagnostics(g, x, y, w, h); break;
        case PAGE_RECOVERY: DrawRecovery(g, x, y, w, h); break;
        case PAGE_CLEANUP: DrawCleanup(g, x, y, w, h); break;
        case PAGE_BSOD: DrawBsod(g, x, y, w, h); break;
        case PAGE_SETTINGS: DrawSettings(g, x, y, w, h); break;
        case PAGE_REGISTRY: DrawRegistry(g, x, y, w, h); break;
        case PAGE_DISKS: DrawDisks(g, x, y, w, h); break;
        }
        g.Restore(state);
    }

    void Paint(HWND hwnd)
    {
        PAINTSTRUCT ps{};
        HDC hdc = BeginPaint(hwnd, &ps);
        RECT client{};
        GetClientRect(hwnd, &client);
        const int width = client.right - client.left;
        const int height = client.bottom - client.top;

        if (width > 0 && height > 0)
        {
            // Render the complete frame off-screen, then copy it to the window
            // in one operation to avoid exposing intermediate drawing steps.
            Bitmap backBuffer(width, height, PixelFormat32bppPARGB);
            if (backBuffer.GetLastStatus() == Ok)
            {
                Graphics frame(&backBuffer);
                frame.SetSmoothingMode(SmoothingModeAntiAlias);
                frame.SetTextRenderingHint(TextRenderingHintClearTypeGridFit);
                frame.Clear(C_BG);

                hitRegions.clear();
                DrawSidebar(frame, height);
                DrawHeader(frame, width);
                DrawContent(frame, width, height);
                DrawFooter(frame, width, height);

                Graphics output(hdc);
                output.SetCompositingMode(CompositingModeSourceCopy);
                output.DrawImage(&backBuffer, 0, 0, width, height);
            }
            else
            {
                // Safe fallback if the off-screen bitmap cannot be allocated.
                Graphics frame(hdc);
                frame.SetSmoothingMode(SmoothingModeAntiAlias);
                frame.SetTextRenderingHint(TextRenderingHintClearTypeGridFit);
                frame.Clear(C_BG);
                hitRegions.clear();
                DrawSidebar(frame, height);
                DrawHeader(frame, width);
                DrawContent(frame, width, height);
                DrawFooter(frame, width, height);
            }
        }
        EndPaint(hwnd, &ps);
    }

    bool PromptCredentials(const std::wstring& message,
        std::wstring& username, std::wstring& password)
    {
        wchar_t user[ CREDUI_MAX_USERNAME_LENGTH + 1 ]{};
        wchar_t pass[ CREDUI_MAX_PASSWORD_LENGTH + 1 ]{};
        lstrcpynW(user, username.c_str(), CREDUI_MAX_USERNAME_LENGTH);
        CREDUI_INFOW info{};
        info.cbSize = sizeof(info);
        info.hwndParent = mainWindow;
        info.pszCaptionText = L"UnlockTool";
        info.pszMessageText = message.c_str();
        ULONG authPackage = 0;
        BOOL save = FALSE;
        DWORD r = CredUIPromptForCredentialsW(&info, L"UnlockTool",
            nullptr, 0, user, CREDUI_MAX_USERNAME_LENGTH,
            pass, CREDUI_MAX_PASSWORD_LENGTH, &save,
            CREDUI_FLAGS_GENERIC_CREDENTIALS | CREDUI_FLAGS_DO_NOT_PERSIST |
            CREDUI_FLAGS_ALWAYS_SHOW_UI | CREDUI_FLAGS_EXCLUDE_CERTIFICATES);
        if (r != ERROR_SUCCESS) return false;
        username = user;
        password = pass;
        SecureZeroMemory(pass, sizeof(pass));
        return true;
    }

    bool SelectFolder(std::wstring& path, const std::wstring& title)
    {
        BROWSEINFOW bi{};
        bi.hwndOwner = mainWindow;
        bi.lpszTitle = title.c_str();
        bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE | BIF_USENEWUI;
        PIDLIST_ABSOLUTE pid = SHBrowseForFolderW(&bi);
        if (!pid) return false;
        wchar_t selected[MAX_PATH]{};
        bool ok = SHGetPathFromIDListW(pid, selected) != FALSE;
        CoTaskMemFree(pid);
        if (ok) path = selected;
        return ok;
    }

    bool SelectDriveLetter(std::wstring& partition)
    {
        HMENU menu = CreatePopupMenu();
        if (!menu) return false;
        std::vector<std::wstring> drives;
        for (wchar_t c = L'A'; c <= L'Z'; ++c)
        {
            wchar_t root[] = { c, L':', L'\\', L'\0' };
            if (GetDriveTypeW(root) != DRIVE_NO_ROOT_DIR)
            {
                drives.push_back(std::wstring(1, c) + L":");
                AppendMenuW(menu, MF_STRING, static_cast<UINT_PTR>(drives.size()),
                    drives.back().c_str());
            }
        }
        POINT pt{}; GetCursorPos(&pt);
        UINT cmd = TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON,
            pt.x, pt.y, 0, mainWindow, nullptr);
        DestroyMenu(menu);
        if (!cmd || cmd > drives.size()) return false;
        partition = drives[cmd - 1];
        return true;
    }

    void StartBootloaderRepair()
    {
        if (IsWinRE())
        {
            MessageBoxW(mainWindow,
                L"Bootloader repair is disabled in WinRE in this build because the current module does not accept an explicit offline Windows installation.",
                APP_TITLE, MB_OK | MB_ICONWARNING);
            return;
        }
        std::wstring windowsDir;
        if (!SelectFolder(windowsDir, L"Select the Windows installation directory (usually C:\\Windows)"))
            return;
        if (!BootloaderRepair::ValidateWindowsDirectory(windowsDir))
        {
            MessageBoxW(mainWindow, L"The selected folder is not a valid Windows installation.",
                APP_TITLE, MB_OK | MB_ICONERROR);
            return;
        }
        std::wstring partition;
        if (!SelectDriveLetter(partition)) return;
        HMENU menu = CreatePopupMenu();
        AppendMenuW(menu, MF_STRING, 1, L"UEFI");
        AppendMenuW(menu, MF_STRING, 2, L"BIOS");
        AppendMenuW(menu, MF_STRING, 3, L"ALL");
        POINT pt{}; GetCursorPos(&pt);
        UINT mode = TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON,
            pt.x, pt.y, 0, mainWindow, nullptr);
        DestroyMenu(menu);
        if (mode < 1 || mode > 3) return;

        std::wstring warning =
            L"BCDBoot will write boot files to " + partition +
            L". Confirm that this is the correct EFI/System partition. Continue?";
        if (MessageBoxW(mainWindow, warning.c_str(), APP_TITLE,
            MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) return;

        bootRunning = true;
        SetStatus(L"Bootloader repair is running...");
        const auto firmware = mode == 1 ? BootloaderRepair::FirmwareType::UEFI :
            mode == 2 ? BootloaderRepair::FirmwareType::BIOS : BootloaderRepair::FirmwareType::All;
        std::thread([hwnd = mainWindow, windowsDir, partition, firmware]()
        {
            auto payload = std::make_unique<BootPayload>();
            payload->result = BootloaderRepair::Repair(windowsDir, partition, firmware);
            if (!PostMessageW(hwnd, WM_APP_BOOT_COMPLETE, 0,
                reinterpret_cast<LPARAM>(payload.get())))
                return;
            payload.release();
        }).detach();
    }

    void StartCleanup(bool clean)
    {
        if (cleanupRunning) return;
        std::vector<Cleanup::CleanupItem> work = cleanupItems;
        bool any = false;
        for (auto& item : work) if (item.selected) any = true;
        if (!any)
        {
            SetStatus(L(language == 0 ? L"Выберите хотя бы одну категорию" : L"Select at least one category"));
            return;
        }
        if (clean)
        {
            for (const auto& item : work)
            {
                if (item.selected && !item.scanned)
                {
                    SetStatus(L(language == 0
                        ? L"Сначала выполните сканирование выбранных категорий"
                        : L"Scan the selected categories before cleaning"));
                    return;
                }
            }
            if (MessageBoxW(mainWindow,
                L"Delete the selected temporary data? This operation cannot be undone.",
                APP_TITLE, MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) return;
        }

        cleanupRunning = true;
        SetStatus(clean ? L"Cleanup is running..." : L"Scanning selected categories...");
        std::thread([hwnd = mainWindow, work = std::move(work), clean]() mutable
        {
            auto payload = std::make_unique<CleanupPayload>();
            payload->items = std::move(work);
            payload->clean = clean;
            for (auto& item : payload->items)
            {
                if (!item.selected) continue;
                bool ok = clean ? Cleanup::CleanItem(item) : Cleanup::ScanItem(item);
                if (!ok) payload->success = false;
            }
            payload->message = clean ? L"Cleanup completed." : L"Scan completed.";
            if (!PostMessageW(hwnd, WM_APP_CLEANUP_COMPLETE, 0,
                reinterpret_cast<LPARAM>(payload.get())))
                return;
            payload.release();
        }).detach();
    }

    void StartUpdateCheck(bool interactive)
    {
        if (updateRunning)
        {
            if (interactive) MessageBoxW(mainWindow, L"Update check is already running.",
                APP_TITLE, MB_OK | MB_ICONINFORMATION);
            return;
        }
        updateRunning = true;
        SetStatus(L(language == 0 ? L"Проверка обновлений..." : L"Checking for updates..."));
        if (!UpdateChecker::CheckAsync(mainWindow, WM_APP_UPDATE_COMPLETE, APP_VERSION, interactive))
        {
            updateRunning = false;
            SetStatus(L(language == 0 ? L"Не удалось запустить проверку" : L"Could not start update check"));
        }
    }

    void CompleteUpdateCheck(WPARAM wParam, LPARAM lParam)
    {
        std::unique_ptr<UpdateChecker::Result> result(reinterpret_cast<UpdateChecker::Result*>(lParam));
        updateRunning = false;
        if (!result) return;
        bool interactive = wParam != 0;
        if (!result->success)
        {
            SetStatus(L(language == 0 ? L"Ошибка проверки обновлений" : L"Update check failed"));
            if (interactive)
                MessageBoxW(mainWindow, result->error.c_str(), L"UnlockTool Update Checker",
                    MB_OK | MB_ICONWARNING);
        }
        else if (result->updateAvailable)
        {
            std::wstring message = L(language == 0 ? L"Доступна версия " : L"Version ") +
                result->latestVersion + L"\n\n" + result->releaseName + L"\n\n" +
                (language == 0 ? L"Открыть страницу релиза?" : L"Open release page?");
            if (interactive && MessageBoxW(mainWindow, message.c_str(),
                L"UnlockTool Update Checker", MB_YESNO | MB_ICONINFORMATION) == IDYES)
                ShellExecuteW(mainWindow, L"open", result->releaseUrl.c_str(),
                    nullptr, nullptr, SW_SHOWNORMAL);
            SetStatus(L(language == 0 ? L"Доступно обновление UnlockTool" : L"UnlockTool update available"));
        }
        else
        {
            SetStatus(L(language == 0 ? L"Установлена последняя версия" : L"Application is up to date"));
            if (interactive)
                MessageBoxW(mainWindow, result->currentVersion.c_str(),
                    L"UnlockTool Update Checker", MB_OK | MB_ICONINFORMATION);
        }
        InvalidateRect(mainWindow, nullptr, FALSE);
    }

    void EnableUac()
    {
        HKEY key = nullptr;
        const wchar_t subkey[] = L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System";
        LONG r = RegOpenKeyExW(HKEY_LOCAL_MACHINE, subkey, 0, KEY_QUERY_VALUE | KEY_SET_VALUE, &key);
        if (r != ERROR_SUCCESS)
        {
            SetStatus(L(language == 0 ? L"Не удалось открыть раздел UAC реестра" : L"Could not open UAC registry key"));
            return;
        }
        DWORD oldValue = 0, type = 0, size = sizeof(oldValue);
        r = RegQueryValueExW(key, L"EnableLUA", nullptr, &type,
            reinterpret_cast<BYTE*>(&oldValue), &size);
        bool existed = r == ERROR_SUCCESS;
        if (existed && (type != REG_DWORD || size != sizeof(oldValue)))
        {
            RegCloseKey(key);
            SetStatus(L"Unsupported EnableLUA registry type");
            return;
        }
        if (!existed && r != ERROR_FILE_NOT_FOUND)
        {
            RegCloseKey(key);
            SetStatus(L"Could not read EnableLUA");
            return;
        }
        if (existed && oldValue == 1)
        {
            RegCloseKey(key);
            SetStatus(L(language == 0 ? L"UAC уже включён" : L"UAC is already enabled"));
            return;
        }
        if (MessageBoxW(mainWindow,
            L"Enable UAC? A backup of the current registry value will be saved. A restart may be required.",
            APP_TITLE, MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES)
        {
            RegCloseKey(key); return;
        }

        wchar_t local[MAX_PATH]{};
        if (FAILED(SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, SHGFP_TYPE_CURRENT, local)))
        {
            RegCloseKey(key); return;
        }
        std::wstring folder = std::wstring(local) + L"\\UnlockTool\\RegistryBackups";
        CreateDirectoryW((std::wstring(local) + L"\\UnlockTool").c_str(), nullptr);
        CreateDirectoryW(folder.c_str(), nullptr);
        std::wstring backup = folder + L"\\EnableUAC-backup.reg";
        std::wstring text = L"Windows Registry Editor Version 5.00\r\n\r\n"
            L"[HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System]\r\n";
        if (existed)
        {
            wchar_t v[32]{}; swprintf_s(v, L"%08X", oldValue);
            text += L"\"EnableLUA\"=dword:" + std::wstring(v) + L"\r\n";
        }
        else text += L"\"EnableLUA\"=-\r\n";
        HANDLE f = CreateFileW(backup.c_str(), GENERIC_WRITE, FILE_SHARE_READ,
            nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (f == INVALID_HANDLE_VALUE) { RegCloseKey(key); return; }
        const BYTE bom[] = { 0xFF, 0xFE };
        DWORD written = 0;
        bool ok = WriteFile(f, bom, 2, &written, nullptr) && written == 2;
        if (ok)
        {
            DWORD bytes = static_cast<DWORD>(text.size() * sizeof(wchar_t));
            ok = WriteFile(f, text.data(), bytes, &written, nullptr) && written == bytes;
        }
        CloseHandle(f);
        if (!ok) { RegCloseKey(key); return; }
        DWORD enabled = 1;
        r = RegSetValueExW(key, L"EnableLUA", 0, REG_DWORD,
            reinterpret_cast<const BYTE*>(&enabled), sizeof(enabled));
        RegCloseKey(key);
        if (r == ERROR_SUCCESS)
        {
            SetStatus(L(language == 0 ? L"UAC включён; резервная копия сохранена" : L"UAC enabled; backup saved"));
            MessageBoxW(mainWindow, L"UAC enabled. Restart Windows to apply the change.",
                APP_TITLE, MB_OK | MB_ICONINFORMATION);
        }
        else SetStatus(L"Could not enable UAC");
    }

    void HandleAction(Hit hit, int data)
    {
        if (IsWinRE() &&
            (hit == HIT_DIAG_SFC || hit == HIT_RECOVERY_SFC ||
             hit == HIT_RECOVERY_DISM || hit == HIT_RECOVERY_CHKDSK ||
             hit == HIT_RECOVERY_UAC))
        {
            MessageBoxW(mainWindow,
                L"This action targets the currently running Windows installation. In WinRE, the current module does not select an offline Windows installation, so the action is blocked.",
                APP_TITLE, MB_OK | MB_ICONWARNING);
            return;
        }

        switch (hit)
        {
        case HIT_NAV: Navigate(data); break;
        case HIT_TASK_REFRESH:
            RefreshProcesses(); SetStatus(L(language == 0 ? L"Список процессов обновлён" : L"Process list refreshed")); break;
        case HIT_TASK_STARTUP:
            ShowStartupEntries(mainWindow);
            SetStatus(L(language == 0 ? L"Список автозагрузки открыт" : L"Startup entries displayed"));
            break;
        case HIT_TASK_ROW:
        {
            DWORD pid = static_cast<DWORD>(data);
            selectedTask = -1;
            for (int i = 0; i < static_cast<int>(processes.size()); ++i)
                if (processes[i].pid == pid) { selectedTask = i; break; }
            SetStatus(L(language == 0 ? L"Выбран процесс" : L"Process selected"));
            break;
        }
        case HIT_TASK_END:
        case HIT_TASK_SUSPEND:
        case HIT_TASK_RESUME:
            if (selectedTask < 0 || selectedTask >= static_cast<int>(processes.size())) break;
            {
                const auto p = processes[selectedTask];
                if (p.isCritical)
                {
                    MessageBoxW(mainWindow, L"Windows has marked this process as critical. The operation is disabled.",
                        APP_TITLE, MB_OK | MB_ICONWARNING); break;
                }
                if (hit == HIT_TASK_END)
                {
                    std::wstring msg = L"Terminate process \"" + p.name + L"\" (PID " +
                        std::to_wstring(p.pid) + L")?";
                    if (MessageBoxW(mainWindow, msg.c_str(), APP_TITLE,
                        MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES)
                        SetStatus(TaskManager::EndProcess(p.pid)
                            ? L(language == 0 ? L"Процесс завершён" : L"Process terminated")
                            : L(language == 0 ? L"Не удалось завершить процесс" : L"Could not terminate process"));
                }
                else if (hit == HIT_TASK_SUSPEND)
                    SetStatus(TaskManager::SuspendProcess(p.pid)
                        ? L"Process suspended" : L"Could not suspend process");
                else
                    SetStatus(TaskManager::ResumeProcess(p.pid)
                        ? L"Process resumed" : L"Could not resume process");
                RefreshProcesses();
            }
            break;

        case HIT_CLEANUP_TOGGLE:
            if (data >= 0 && data < static_cast<int>(cleanupItems.size()))
            {
                cleanupItems[data].selected = !cleanupItems[data].selected;
                cleanupItems[data].scanned = false;
                cleanupItems[data].size = 0;
                cleanupItems[data].filesCount = 0;
            }
            break;
        case HIT_CLEANUP_SCAN: StartCleanup(false); break;
        case HIT_CLEANUP_RUN: StartCleanup(true); break;

        case HIT_USER_REFRESH: LoadUsers(); SetStatus(L"User list refreshed"); break;
        case HIT_USER_ROW: selectedUser = data; break;
        case HIT_USER_CREATE:
        {
            std::wstring username, password;
            if (PromptCredentials(L"Enter the new local account name and password.", username, password))
            {
                NET_API_STATUS r = Users::CreateUser(username, password);
                SecureZeroMemory(password.data(), password.size() * sizeof(wchar_t));
                SetStatus(r == NERR_Success ? L"User created" : L"Could not create user. NetAPI status: " + std::to_wstring(r));
                LoadUsers();
            }
            break;
        }
        case HIT_USER_ENABLE:
        case HIT_USER_DISABLE:
        case HIT_USER_DELETE:
        case HIT_USER_PASSWORD:
            if (selectedUser >= 0 && selectedUser < static_cast<int>(users.size()))
            {
                const std::wstring name = users[selectedUser].username;
                if (hit == HIT_USER_DELETE)
                {
                    std::wstring msg = L"Delete local account \"" + name + L"\"?";
                    if (MessageBoxW(mainWindow, msg.c_str(), APP_TITLE,
                        MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES)
                    {
                        auto r = Users::DeleteUser(name);
                        SetStatus(r == NERR_Success ? L"User deleted" : L"Could not delete user: " + std::to_wstring(r));
                        LoadUsers();
                    }
                }
                else if (hit == HIT_USER_ENABLE || hit == HIT_USER_DISABLE)
                {
                    auto r = hit == HIT_USER_ENABLE ? Users::EnableUser(name) : Users::DisableUser(name);
                    SetStatus(r == NERR_Success ? L"User state updated" : L"Could not update user: " + std::to_wstring(r));
                    LoadUsers();
                }
                else
                {
                    std::wstring u = name, p;
                    if (PromptCredentials(L"Enter the new password for the selected local account.", u, p))
                    {
                        auto r = Users::ChangePassword(name, p);
                        SecureZeroMemory(p.data(), p.size() * sizeof(wchar_t));
                        SetStatus(r == NERR_Success ? L"Password changed" : L"Could not change password: " + std::to_wstring(r));
                    }
                }
            }
            break;

        case HIT_DIAG_SYSTEM: LaunchSystem(L"msinfo32.exe"); break;
        case HIT_DIAG_SFC:
            if (MessageBoxW(mainWindow, L"Run System File Checker in verification-only mode?",
                APP_TITLE, MB_YESNO | MB_ICONQUESTION) == IDYES)
                LaunchElevated(L"sfc /verifyonly");
            break;
        case HIT_DIAG_SERVICES: LaunchSystem(L"services.msc"); break;
        case HIT_DIAG_DEBUG_SCAN: LoadDebuggerEntries(); SetStatus(L"IFEO scan completed"); break;
        case HIT_DEBUG_ROW: selectedDebugger = data; break;
        case HIT_DEBUG_REMOVE:
            if (selectedDebugger >= 0 && selectedDebugger < static_cast<int>(debuggerEntries.size()))
            {
                const auto entry = debuggerEntries[selectedDebugger];
                if (MessageBoxW(mainWindow, L"Remove this IFEO Debugger registry value? A backup will be created.",
                    APP_TITLE, MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES)
                {
                    wchar_t local[MAX_PATH]{};
                    SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, SHGFP_TYPE_CURRENT, local);
                    std::wstring dir = std::wstring(local) + L"\\UnlockTool\\RegistryBackups";
                    CreateDirectoryW((std::wstring(local) + L"\\UnlockTool").c_str(), nullptr);
                    CreateDirectoryW(dir.c_str(), nullptr);
                    std::wstring backup = dir + L"\\IFEO-" + entry.imageName + L".reg";
                    std::wstring error;
                    bool ok = DebuggerDetector::Remove(entry, backup, error);
                    SetStatus(ok ? L"IFEO debugger entry removed" : L"Could not remove IFEO entry: " + error);
                    LoadDebuggerEntries();
                }
            }
            break;

        case HIT_RECOVERY_SFC:
            if (MessageBoxW(mainWindow, L"Run sfc /scannow with administrator privileges?",
                APP_TITLE, MB_YESNO | MB_ICONWARNING) == IDYES) LaunchElevated(L"sfc /scannow");
            break;
        case HIT_RECOVERY_DISM:
            if (MessageBoxW(mainWindow, L"Run DISM RestoreHealth? This can take a long time.",
                APP_TITLE, MB_YESNO | MB_ICONWARNING) == IDYES)
                LaunchElevated(L"DISM /Online /Cleanup-Image /RestoreHealth");
            break;
        case HIT_RECOVERY_CHKDSK:
            if (MessageBoxW(mainWindow, L"Run CHKDSK online scan on C:?",
                APP_TITLE, MB_YESNO | MB_ICONWARNING) == IDYES) LaunchElevated(L"chkdsk C: /scan");
            break;
        case HIT_RECOVERY_WINRE:
            if (IsWinRE())
                MessageBoxW(mainWindow, L"UnlockTool is already running in WinRE.", APP_TITLE, MB_OK | MB_ICONINFORMATION);
            else if (MessageBoxW(mainWindow, L"Windows will restart into Advanced Startup. Save your work first. Continue?",
                APP_TITLE, MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES)
                LaunchSystem(L"shutdown.exe", L"/r /o /t 0", true);
            break;
        case HIT_RECOVERY_UAC: EnableUac(); break;
        case HIT_RECOVERY_BOOT: StartBootloaderRepair(); break;

        case HIT_BSOD_REFRESH: LoadBsod(); SetStatus(L"BSOD history refreshed"); break;
        case HIT_BSOD_DUMPS: BSODMonitor::OpenDumpFolder(); break;
        case HIT_BSOD_EVENT: BSODMonitor::OpenEventViewer(); break;
        case HIT_BSOD_RELIABILITY: BSODMonitor::OpenReliabilityMonitor(); break;
        case HIT_BSOD_EXPORT:
        {
            std::wstring txt, html;
            if (BSODMonitor::ExportReports(txt, html))
                ShellExecuteW(mainWindow, L"open", html.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
            else SetStatus(L"Could not export BSOD reports");
            break;
        }
        case HIT_BSOD_ROW: selectedIncident = data; break;

        case HIT_SETTING_LANGUAGE:
            language = 1 - language; SaveLanguage(); SetStatus(L"Interface language changed"); break;
        case HIT_SETTING_AUTOCHECK:
            autoCheckUpdates = !autoCheckUpdates; WriteSetting(L"Updates", L"AutoCheck", autoCheckUpdates); break;
        case HIT_SETTING_AUTOSTART:
            autoStartEnabled = !autoStartEnabled;
            if (!SetStartupEnabled(autoStartEnabled))
            {
                autoStartEnabled = !autoStartEnabled;
                SetStatus(L"Could not change startup setting");
            }
            else
            {
                WriteSetting(L"General", L"AutoStart", autoStartEnabled);
                SetStatus(L"Startup setting updated");
            }
            break;
        case HIT_SETTING_NOTIFICATIONS:
            notificationsEnabled = !notificationsEnabled;
            WriteSetting(L"Notifications", L"Enabled", notificationsEnabled);
            if (notificationsEnabled) CheckBsodStartupNotification(mainWindow);
            else RemoveBsodTrayIcon();
            break;
        case HIT_SETTING_ANIMATIONS:
            animationsEnabled = !animationsEnabled;
            WriteSetting(L"General", L"Animations", animationsEnabled);
            if (!animationsEnabled)
            {
                navIconAnimation = 1.0f;
                pageTransition = 1.0f;
                KillTimer(mainWindow, TIMER_ANIMATION);
            }
            else if (windowIsActive &&
                (navIconAnimation < 1.0f || pageTransition < 1.0f))
            {
                SetTimer(mainWindow, TIMER_ANIMATION, 16, nullptr);
            }
            break;
        case HIT_SETTING_APPEARANCE:
            if (MessageBoxW(mainWindow, L"Restore the default Windows theme and font smoothing?",
                APP_TITLE, MB_YESNO | MB_ICONQUESTION) == IDYES)
            {
                auto r = AppearanceRepair::RestoreDefaultAppearance();
                SetStatus(r.message);
                MessageBoxW(mainWindow, r.message.c_str(), APP_TITLE,
                    MB_OK | (r.success ? MB_ICONINFORMATION : MB_ICONWARNING));
            }
            break;
        case HIT_SETTING_UPDATE: StartUpdateCheck(true); break;

        case HIT_REGISTRY_REFRESH: LoadRegistry(); SetStatus(L"Registry values refreshed"); break;
        case HIT_REGISTRY_ROW: selectedRegistry = data; break;
        case HIT_REGISTRY_EDIT:
            if (selectedRegistry >= 0 && selectedRegistry < static_cast<int>(registryItems.size()))
            {
                auto info = registryItems[selectedRegistry];
                if (!info.readable)
                {
                    SetStatus(L"Cannot edit an unreadable registry value");
                    break;
                }
                std::wstring newValue;
                std::wstring prompt = L"Новое значение для " + info.name +
                    L". Тип реестра будет сохранён. Для REG_MULTI_SZ используйте новую строку между элементами.";
                if (PromptForText(mainWindow, L"Изменение параметра реестра", prompt,
                    info.currentValue, newValue))
                {
                    if (MessageBoxW(mainWindow,
                        L"Изменение критического параметра Windows может повлиять на запуск системы. Перед записью будет сохранена временная копия для отката при ошибке. Продолжить?",
                        APP_TITLE, MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES)
                    {
                        RegistryRepair::BackupInfo backup{};
                        LONG error = ERROR_SUCCESS;
                        bool ok = RegistryRepair::SetCustomValue(info.parameter, newValue, backup, error);
                        SetStatus(ok ? L"Registry value updated (backup captured)" :
                            RegistryRepair::GetErrorMessage(error));
                        LoadRegistry();
                    }
                }
            }
            break;

        case HIT_REGISTRY_RESTORE:
            if (selectedRegistry >= 0 && selectedRegistry < static_cast<int>(registryItems.size()))
            {
                auto param = registryItems[selectedRegistry].parameter;
                if (MessageBoxW(mainWindow,
                    L"Restore this registry parameter to its expected default? A backup will be created first.",
                    APP_TITLE, MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES)
                {
                    RegistryRepair::BackupInfo backup{};
                    LONG error = ERROR_SUCCESS;
                    bool ok = RegistryRepair::RestoreDefault(param, backup, error);
                    SetStatus(ok ? L"Registry parameter restored" :
                        RegistryRepair::GetErrorMessage(error));
                    LoadRegistry();
                }
            }
            break;

        case HIT_DISK_ROW:
            if (data == -1) { LoadDisks(); SetStatus(L"Volumes refreshed"); }
            else selectedDisk = data;
            break;
        case HIT_DISK_MANAGEMENT: DiskManager::OpenDiskManagement(); break;
        case HIT_DISK_OPEN:
        case HIT_DISK_SCAN:
        case HIT_DISK_BITLOCKER:
            if (selectedDisk >= 0 && selectedDisk < static_cast<int>(disks.size()))
            {
                const auto volume = disks[selectedDisk];
                bool ok = hit == HIT_DISK_OPEN ? DiskManager::OpenVolume(volume) :
                    hit == HIT_DISK_SCAN ? DiskManager::RunFileSystemScan(volume) :
                    DiskManager::ShowBitLockerStatus(volume);
                SetStatus(ok ? L"Disk action launched" : L"Disk action failed or is unavailable");
            }
            break;
        default: break;
        }
        InvalidateRect(mainWindow, nullptr, FALSE);
    }

    void HandleClick(int x, int y)
    {
        for (auto it = hitRegions.rbegin(); it != hitRegions.rend(); ++it)
        {
            if (Contains(it->rect, x, y))
            {
                if (it->hit == HIT_NONE)
                {
                    if (currentPage == PAGE_TASKS && y >= HEADER_HEIGHT + 22 + 48)
                    {
                        processSearchFocused = true;
                    }
                    InvalidateRect(mainWindow, nullptr, FALSE);
                    return;
                }
                processSearchFocused = false;
                HandleAction(it->hit, it->data);
                return;
            }
        }
        processSearchFocused = false;
    }

    void UpdateHover(int x, int y)
    {
        int next = -1;
        if (x < SIDEBAR_WIDTH)
        {
            for (int i = 0; i < PAGE_COUNT; ++i)
            {
                RECT r = MakeRect(12, 120 + i * 43, SIDEBAR_WIDTH - 24, 37);
                if (Contains(r, x, y)) { next = i; break; }
            }
        }
        if (next != hoveredNav)
        {
            hoveredNav = next;
            InvalidateRect(mainWindow, nullptr, FALSE);
        }
    }

    LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
    {
        switch (msg)
        {
        case WM_CREATE:
            mainWindow = hwnd;
            SetTimer(hwnd, TIMER_TASK_REFRESH, TASK_REFRESH_MS, nullptr);
            return 0;

        case WM_GETMINMAXINFO:
        {
            auto* mmi = reinterpret_cast<MINMAXINFO*>(lp);
            mmi->ptMinTrackSize.x = 1040;
            mmi->ptMinTrackSize.y = 680;
            return 0;
        }

        case WM_PAINT:
            Paint(hwnd);
            return 0;

        case WM_ERASEBKGND:
            return 1;

        case WM_MOUSEMOVE:
            UpdateHover(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
            return 0;

        case WM_LBUTTONDOWN:
            HandleClick(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
            return 0;

        case WM_CHAR:
            if (currentPage == PAGE_TASKS && processSearchFocused)
            {
                if (wp == VK_BACK)
                {
                    if (!processSearch.empty()) processSearch.pop_back();
                }
                else if (wp >= 32 && wp < 127 && processSearch.size() < 128)
                {
                    processSearch.push_back(static_cast<wchar_t>(wp));
                }
                taskScroll = 0;
                selectedTask = -1;
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
            break;

        case WM_KEYDOWN:
            if (wp == VK_ESCAPE && processSearchFocused)
            {
                processSearchFocused = false;
                processSearch.clear();
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
            break;

        case WM_RBUTTONUP:
            if (currentPage == PAGE_TASKS)
            {
                const int mx = GET_X_LPARAM(lp);
                const int my = GET_Y_LPARAM(lp);
                const int tableTop = HEADER_HEIGHT + 22 + 96 + 31;
                RECT client{}; GetClientRect(hwnd, &client);
                const int contentX = SIDEBAR_WIDTH + 28;
                const int contentW = client.right - contentX - 28;
                if (mx >= contentX && mx < contentX + contentW &&
                    my >= tableTop && my < client.bottom - FOOTER_HEIGHT - 8)
                {
                    auto filtered = TaskManager::SearchProcesses(processes, processSearch);
                    const int row = (my - tableTop) / 31;
                    const int index = row + taskScroll;
                    if (index >= 0 && index < static_cast<int>(filtered.size()))
                    {
                        const DWORD pid = filtered[index].pid;
                        selectedTask = -1;
                        for (int i = 0; i < static_cast<int>(processes.size()); ++i)
                            if (processes[i].pid == pid) { selectedTask = i; break; }
                        if (selectedTask >= 0)
                        {
                            const auto process = processes[selectedTask];
                            HMENU menu = CreatePopupMenu();
                            AppendMenuW(menu, process.exePath.empty() ? MF_STRING | MF_GRAYED : MF_STRING,
                                1, language == 0 ? L"Открыть расположение файла" : L"Open file location");
                            AppendMenuW(menu, process.isCritical ? MF_STRING | MF_GRAYED : MF_STRING,
                                2, process.isSuspended
                                    ? (language == 0 ? L"Возобновить" : L"Resume")
                                    : (language == 0 ? L"Приостановить" : L"Suspend"));
                            AppendMenuW(menu, process.isCritical ? MF_STRING | MF_GRAYED : MF_STRING,
                                3, language == 0 ? L"Завершить процесс" : L"End process");
                            POINT pt{ mx, my }; ClientToScreen(hwnd, &pt);
                            UINT command = TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON,
                                pt.x, pt.y, 0, hwnd, nullptr);
                            DestroyMenu(menu);
                            if (command == 1 && !process.exePath.empty())
                            {
                                std::wstring args = L"/select,\"";
                                args += process.exePath;
                                args += L"\"";

                                ShellExecuteW(
                                    hwnd,
                                    L"open",
                                    L"explorer.exe",
                                    args.c_str(),
                                    nullptr,
                                    SW_SHOWNORMAL
                                );
                            }
                            else if (command == 2)
                            {
                                if (process.isSuspended)
                                    TaskManager::ResumeProcess(pid);
                                else
                                    TaskManager::SuspendProcess(pid);

                                RefreshProcesses();
                            }
                            else if (command == 3)
                            {
                                if (MessageBoxW(
                                    hwnd,
                                    L"Terminate the selected process?",
                                    APP_TITLE,
                                    MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2
                                ) == IDYES)
                                {
                                    TaskManager::EndProcess(pid);
                                    RefreshProcesses();
                                }
                            }
                    }
                }
                }
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
            break;

        case WM_MOUSEWHEEL:
            if (currentPage == PAGE_TASKS)
            {
                int delta = GET_WHEEL_DELTA_WPARAM(wp);
                taskScroll = (std::max)(0, taskScroll + (delta < 0 ? 3 : -3));
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
            break;

        case WM_ACTIVATE:
            windowIsActive = (LOWORD(wp) != WA_INACTIVE);
            if (!windowIsActive)
            {
                KillTimer(hwnd, TIMER_ANIMATION);
            }
            else if (animationsEnabled &&
                (navIconAnimation < 1.0f || pageTransition < 1.0f))
            {
                SetTimer(hwnd, TIMER_ANIMATION, 16, nullptr);
            }
            return 0;

        case WM_SIZE:
            if (wp == SIZE_MINIMIZED)
            {
                windowIsActive = false;
                KillTimer(hwnd, TIMER_ANIMATION);
            }
            else
            {
                InvalidateRect(hwnd, nullptr, FALSE);
            }
            return 0;

        case WM_TIMER:
            if (wp == TIMER_TASK_REFRESH && currentPage == PAGE_TASKS && !cleanupRunning)
            {
                RefreshProcesses();
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
            if (wp == TIMER_ANIMATION)
            {
                if (!windowIsActive || !animationsEnabled)
                {
                    KillTimer(hwnd, TIMER_ANIMATION);
                    return 0;
                }

                bool keepTimer = false;
                if (navIconAnimation < 1.0f)
                {
                    navIconAnimation = (std::min)(1.0f, navIconAnimation + 0.10f);
                    keepTimer = navIconAnimation < 1.0f;
                }
                if (pageTransition < 1.0f)
                {
                    pageTransition = (std::min)(1.0f, pageTransition + 0.14f);
                    keepTimer = keepTimer || pageTransition < 1.0f;
                }

                if (!keepTimer) KillTimer(hwnd, TIMER_ANIMATION);
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
            break;

        case WM_APP_UPDATE_COMPLETE:
            CompleteUpdateCheck(wp, lp);
            return 0;

        case WM_APP_CLEANUP_COMPLETE:
        {
            std::unique_ptr<CleanupPayload> payload(reinterpret_cast<CleanupPayload*>(lp));
            cleanupRunning = false;
            if (payload)
            {
                cleanupItems = std::move(payload->items);
                SetStatus(payload->success ? payload->message :
                    (language == 0 ? L"Операция завершена с ошибками" : L"Operation completed with errors"));
            }
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }

        case WM_APP_BOOT_COMPLETE:
        {
            std::unique_ptr<BootPayload> payload(reinterpret_cast<BootPayload*>(lp));
            bootRunning = false;
            if (payload)
            {
                SetStatus(payload->result.message);
                MessageBoxW(hwnd, payload->result.message.c_str(), APP_TITLE,
                    MB_OK | (payload->result.success ? MB_ICONINFORMATION : MB_ICONERROR));
            }
            return 0;
        }

        case WM_DESTROY:
            RemoveBsodTrayIcon();
            KillTimer(hwnd, TIMER_TASK_REFRESH);
            KillTimer(hwnd, TIMER_ANIMATION);
            PostQuitMessage(0);
            return 0;
        }
        return DefWindowProcW(hwnd, msg, wp, lp);
    }
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE, LPSTR, int show)
{
    appInstance = instance;
    InitializeSettings();
    autoStartEnabled = IsStartupEnabled();
    statusText = L(language == 0 ? L"Готово" : L"Ready");

    GdiplusStartupInput gdiplus{};
    if (GdiplusStartup(&gdiplusToken, &gdiplus, nullptr) != Ok)
    {
        MessageBoxW(nullptr, L"Could not initialize GDI+.", APP_TITLE, MB_OK | MB_ICONERROR);
        return 1;
    }

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hIcon = LoadIconW(instance, MAKEINTRESOURCEW(IDI_APP_ICON));
    wc.hIconSm = wc.hIcon;
    wc.lpszClassName = WINDOW_CLASS;
    wc.hbrBackground = nullptr;

    if (!RegisterClassExW(&wc))
    {
        GdiplusShutdown(gdiplusToken);
        return 1;
    }

    RECT rc{ 0, 0, 1280, 820 };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, FALSE);
    HWND hwnd = CreateWindowExW(0, WINDOW_CLASS, APP_TITLE, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, rc.right - rc.left, rc.bottom - rc.top,
        nullptr, nullptr, instance, nullptr);
    if (!hwnd)
    {
        GdiplusShutdown(gdiplusToken);
        return 1;
    }

    mainWindow = hwnd;
    ShowWindow(hwnd, show);
    UpdateWindow(hwnd);
    CheckBsodStartupNotification(hwnd);

    if (autoCheckUpdates) StartUpdateCheck(false);

    MSG msg{};
    int result = 0;
    while ((result = GetMessageW(&msg, nullptr, 0, 0)) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    GdiplusShutdown(gdiplusToken);
    return result == -1 ? 1 : static_cast<int>(msg.wParam);
}
