#include "DebuggerDetector.h"

#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

#pragma comment(lib, "Advapi32.lib")

namespace DebuggerDetector
{
    namespace
    {
        constexpr wchar_t BASE_PATH[] =
            L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"
            L"\\Image File Execution Options";

        HKEY GetRootKey(RegistryHive hive)
        {
            switch (hive)
            {
            case RegistryHive::LocalMachine:
                return HKEY_LOCAL_MACHINE;

            case RegistryHive::CurrentUser:
                return HKEY_CURRENT_USER;
            }

            return nullptr;
        }

        const wchar_t* GetHiveName(RegistryHive hive)
        {
            switch (hive)
            {
            case RegistryHive::LocalMachine:
                return L"HKEY_LOCAL_MACHINE";

            case RegistryHive::CurrentUser:
                return L"HKEY_CURRENT_USER";
            }

            return L"";
        }

        bool ReadDebugger(
            HKEY key,
            std::wstring& value,
            DWORD& valueType
        )
        {
            DWORD size = 0;
            valueType = 0;

            LONG status = RegQueryValueExW(
                key,
                L"Debugger",
                nullptr,
                &valueType,
                nullptr,
                &size
            );

            if (status != ERROR_SUCCESS)
                return false;

            if (valueType != REG_SZ &&
                valueType != REG_EXPAND_SZ)
                return false;

            if (size == 0 ||
                size > 1024 * 1024 ||
                size % sizeof(wchar_t) != 0)
                return false;

            std::vector<wchar_t> buffer(
                size / sizeof(wchar_t) + 1,
                L'\0'
            );

            status = RegQueryValueExW(
                key,
                L"Debugger",
                nullptr,
                &valueType,
                reinterpret_cast<BYTE*>(buffer.data()),
                &size
            );

            if (status != ERROR_SUCCESS)
                return false;

            buffer.back() = L'\0';

            value = buffer.data();

            return !value.empty();
        }

        bool WriteBackup(
            const std::wstring& file,
            const DebuggerEntry& entry,
            const std::wstring& value,
            DWORD type
        )
        {
            HANDLE handle = CreateFileW(
                file.c_str(),
                FILE_APPEND_DATA,
                FILE_SHARE_READ,
                nullptr,
                OPEN_ALWAYS,
                FILE_ATTRIBUTE_NORMAL,
                nullptr
            );

            if (handle == INVALID_HANDLE_VALUE)
                return false;

            LARGE_INTEGER fileSize{};

            if (!GetFileSizeEx(handle, &fileSize))
            {
                CloseHandle(handle);
                return false;
            }

            bool success = true;
            DWORD written = 0;

            // Новый REG-файл должен начинаться с UTF-16 BOM.
            if (fileSize.QuadPart == 0)
            {
                const BYTE bom[] = { 0xFF, 0xFE };

                success = WriteFile(
                    handle,
                    bom,
                    sizeof(bom),
                    &written,
                    nullptr
                ) && written == sizeof(bom);
            }

            std::wstring output;

            output += L"Windows Registry Editor Version 5.00\r\n\r\n";
            output += L"[";
            output += GetHiveName(entry.hive);
            output += L"\\";
            output += entry.registryPath;
            output += L"]\r\n";

            if (type == REG_SZ)
            {
                std::wstring escaped;

                for (wchar_t ch : value)
                {
                    if (ch == L'\\' || ch == L'"')
                        escaped += L'\\';

                    escaped += ch;
                }

                output += L"\"Debugger\"=\"";
                output += escaped;
                output += L"\"\r\n\r\n";
            }
            else if (type == REG_EXPAND_SZ)
            {
                output += L"\"Debugger\"=hex(2):";

                const BYTE* bytes =
                    reinterpret_cast<const BYTE*>(value.c_str());

                const size_t byteCount =
                    (value.size() + 1) * sizeof(wchar_t);

                for (size_t i = 0; i < byteCount; ++i)
                {
                    if (i != 0)
                        output += L",";

                    wchar_t hex[4]{};

                    swprintf_s(
                        hex,
                        L"%02x",
                        bytes[i]
                    );

                    output += hex;
                }

                output += L"\r\n\r\n";
            }
            else
            {
                CloseHandle(handle);
                return false;
            }

            if (success)
            {
                DWORD bytesToWrite = static_cast<DWORD>(
                    output.size() * sizeof(wchar_t)
                    );

                success = WriteFile(
                    handle,
                    output.data(),
                    bytesToWrite,
                    &written,
                    nullptr
                ) && written == bytesToWrite;
            }

            CloseHandle(handle);

            return success;
        }

        void ScanHive(
            RegistryHive hive,
            REGSAM view,
            std::vector<DebuggerEntry>& results
        )
        {
            HKEY root = nullptr;

            LONG status = RegOpenKeyExW(
                GetRootKey(hive),
                BASE_PATH,
                0,
                KEY_ENUMERATE_SUB_KEYS | view,
                &root
            );

            if (status != ERROR_SUCCESS)
                return;

            DWORD index = 0;

            std::vector<wchar_t> name(32768);

            while (true)
            {
                DWORD nameSize =
                    static_cast<DWORD>(name.size());

                status = RegEnumKeyExW(
                    root,
                    index++,
                    name.data(),
                    &nameSize,
                    nullptr,
                    nullptr,
                    nullptr,
                    nullptr
                );

                if (status == ERROR_NO_MORE_ITEMS)
                    break;

                if (status != ERROR_SUCCESS)
                    continue;

                std::wstring imageName(
                    name.data(),
                    nameSize
                );

                std::wstring fullPath =
                    std::wstring(BASE_PATH) +
                    L"\\" +
                    imageName;

                HKEY imageKey = nullptr;

                status = RegOpenKeyExW(
                    GetRootKey(hive),
                    fullPath.c_str(),
                    0,
                    KEY_QUERY_VALUE | view,
                    &imageKey
                );

                if (status != ERROR_SUCCESS)
                    continue;

                std::wstring debugger;
                DWORD type = 0;

                if (ReadDebugger(
                    imageKey,
                    debugger,
                    type
                ))
                {
                    DebuggerEntry entry{};

                    entry.hive = hive;
                    entry.registryView = view;
                    entry.imageName = imageName;
                    entry.debuggerPath = debugger;
                    entry.registryPath = fullPath;
                    entry.valueType = type;

                    results.push_back(entry);
                }

                RegCloseKey(imageKey);
            }

            RegCloseKey(root);
        }
    }

    std::vector<DebuggerEntry> Scan()
    {
        std::vector<DebuggerEntry> results;

        ScanHive(
            RegistryHive::LocalMachine,
            KEY_WOW64_64KEY,
            results
        );

        ScanHive(
            RegistryHive::LocalMachine,
            KEY_WOW64_32KEY,
            results
        );

        ScanHive(
            RegistryHive::CurrentUser,
            KEY_WOW64_64KEY,
            results
        );

        ScanHive(
            RegistryHive::CurrentUser,
            KEY_WOW64_32KEY,
            results
        );

        return results;
    }

    bool Remove(
        const DebuggerEntry& entry,
        const std::wstring& backupFile,
        std::wstring& error
    )
    {
        HKEY root = GetRootKey(entry.hive);

        if (root == nullptr)
        {
            error = L"Некорректный раздел реестра.";
            return false;
        }

        if (entry.imageName.empty() ||
            entry.imageName.find(L'\\') != std::wstring::npos ||
            backupFile.empty())
        {
            error = L"Некорректные параметры удаления.";
            return false;
        }

        const std::wstring expectedPath =
            std::wstring(BASE_PATH) +
            L"\\" +
            entry.imageName;

        if (entry.registryPath != expectedPath)
        {
            error = L"Путь реестра не прошёл проверку.";
            return false;
        }

        HKEY key = nullptr;

        LONG status = RegOpenKeyExW(
            root,
            expectedPath.c_str(),
            0,
            KEY_QUERY_VALUE | KEY_SET_VALUE |
            entry.registryView,
            &key
        );

        if (status != ERROR_SUCCESS)
        {
            error = L"Не удалось открыть раздел реестра.";
            return false;
        }

        std::wstring currentValue;
        DWORD currentType = 0;

        if (!ReadDebugger(
            key,
            currentValue,
            currentType
        ))
        {
            RegCloseKey(key);

            error = L"Запись Debugger больше не существует.";
            return false;
        }

        if (currentValue != entry.debuggerPath ||
            currentType != entry.valueType)
        {
            RegCloseKey(key);

            error = L"Значение изменилось после сканирования. Выполните проверку повторно.";
            return false;
        }

        if (!WriteBackup(
            backupFile,
            entry,
            currentValue,
            currentType
        ))
        {
            RegCloseKey(key);

            error = L"Не удалось создать резервную копию.";
            return false;
        }

        status = RegDeleteValueW(
            key,
            L"Debugger"
        );

        RegCloseKey(key);

        if (status != ERROR_SUCCESS)
        {
            error = L"Не удалось удалить значение Debugger. Код ошибки: " +
                std::to_wstring(status);

            return false;
        }

        return true;
    }
}