#include "RegistryRepair.h"

#include <Windows.h>
#include <vector>
#include <string>
#include <cwchar>
#include <cstring>
#include <utility>

namespace RegistryRepair
{
    namespace
    {
        constexpr size_t PARAMETER_COUNT = 7;
        constexpr DWORD MAX_VALUE_SIZE = 1024 * 1024;

        struct ParameterDefinition
        {
            Parameter parameter;
            const wchar_t* name;
            const wchar_t* keyPath;
            const wchar_t* valueName;
            const wchar_t* expectedValue;
            DWORD expectedType;
        };

        const ParameterDefinition definitions[] =
        {
            {
                Parameter::Shell,
                L"Shell",
                L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",
                L"Shell",
                L"explorer.exe",
                REG_SZ
            },
            {
                Parameter::Userinit,
                L"Userinit",
                L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon",
                L"Userinit",
                L"%SystemRoot%\\system32\\userinit.exe,",
                REG_SZ
            },
            {
                Parameter::CmdLine,
                L"CmdLine",
                L"SYSTEM\\Setup",
                L"CmdLine",
                L"",
                REG_SZ
            },
            {
                Parameter::AppInitDlls,
                L"AppInit_DLLs",
                L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Windows",
                L"AppInit_DLLs",
                L"",
                REG_SZ
            },
            {
                Parameter::SetupType,
                L"SetupType",
                L"SYSTEM\\Setup",
                L"SetupType",
                L"0",
                REG_DWORD
            },
            {
                Parameter::CursorSuppression,
                L"EnableCursorSuppression",
                L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
                L"EnableCursorSuppression",
                L"0",
                REG_DWORD
            },
            {
                Parameter::BootExecute,
                L"BootExecute",
                L"SYSTEM\\CurrentControlSet\\Control\\Session Manager",
                L"BootExecute",
                L"autocheck autochk *",
                REG_MULTI_SZ
            }
        };

        REGSAM GetRegistryView()
        {
            BOOL isWow64 = FALSE;

            if (IsWow64Process(
                GetCurrentProcess(),
                &isWow64) && isWow64)
            {
                return KEY_WOW64_64KEY;
            }

            return 0;
        }

        const ParameterDefinition* FindDefinition(
            Parameter parameter)
        {
            for (const auto& definition : definitions)
            {
                if (definition.parameter == parameter)
                    return &definition;
            }

            return nullptr;
        }

        bool IsRestorableParameter(Parameter parameter)
        {
            return FindDefinition(parameter) != nullptr;
        }

        bool IsWindowsSetupActive()
        {
            HKEY key = nullptr;

            LONG error = RegOpenKeyExW(
                HKEY_LOCAL_MACHINE,
                L"SYSTEM\\Setup",
                0,
                KEY_QUERY_VALUE | GetRegistryView(),
                &key
            );

            // Если состояние установки проверить не удалось,
            // безопаснее запретить изменение Setup-параметров.
            if (error != ERROR_SUCCESS)
                return true;

            const wchar_t* flags[] =
            {
                L"SystemSetupInProgress",
                L"OOBEInProgress",
                L"SetupType"
            };

            bool active = false;

            for (const wchar_t* flag : flags)
            {
                DWORD value = 0;
                DWORD type = 0;
                DWORD size = sizeof(value);

                error = RegQueryValueExW(
                    key,
                    flag,
                    nullptr,
                    &type,
                    reinterpret_cast<LPBYTE>(&value),
                    &size
                );

                if (error == ERROR_SUCCESS &&
                    type == REG_DWORD &&
                    size == sizeof(value) &&
                    value != 0)
                {
                    active = true;
                    break;
                }
            }

            RegCloseKey(key);
            return active;
        }

        bool ParseDword(
            const wchar_t* text,
            DWORD& result)
        {
            if (!text || !*text)
                return false;

            wchar_t* end = nullptr;

            unsigned long value =
                std::wcstoul(text, &end, 10);

            if (!end || end == text ||
                *end != L'\0' ||
                value > MAXDWORD)
            {
                return false;
            }

            result = static_cast<DWORD>(value);
            return true;
        }

        bool WriteExpectedValue(
            HKEY key,
            const ParameterDefinition& definition)
        {
            if (definition.expectedType == REG_DWORD)
            {
                DWORD value = 0;

                if (!ParseDword(
                    definition.expectedValue,
                    value))
                {
                    SetLastError(ERROR_INVALID_DATA);
                    return false;
                }

                LONG error = RegSetValueExW(
                    key,
                    definition.valueName,
                    0,
                    REG_DWORD,
                    reinterpret_cast<const BYTE*>(&value),
                    sizeof(value)
                );

                SetLastError(error);
                return error == ERROR_SUCCESS;
            }

            if (definition.expectedType == REG_SZ)
            {
                const std::wstring value =
                    definition.expectedValue;

                LONG error = RegSetValueExW(
                    key,
                    definition.valueName,
                    0,
                    REG_SZ,
                    reinterpret_cast<const BYTE*>(value.c_str()),
                    static_cast<DWORD>(
                        (value.size() + 1) * sizeof(wchar_t)
                        )
                );

                SetLastError(error);
                return error == ERROR_SUCCESS;
            }

            if (definition.expectedType == REG_MULTI_SZ)
            {
                // REG_MULTI_SZ должен заканчиваться двумя NUL.
                const std::wstring value =
                    definition.expectedValue;

                std::vector<wchar_t> data;
                data.reserve(value.size() + 2);

                for (wchar_t ch : value)
                {
                    if (ch == L'\0')
                    {
                        SetLastError(ERROR_INVALID_DATA);
                        return false;
                    }

                    data.push_back(ch);
                }

                data.push_back(L'\0');
                data.push_back(L'\0');

                LONG error = RegSetValueExW(
                    key,
                    definition.valueName,
                    0,
                    REG_MULTI_SZ,
                    reinterpret_cast<const BYTE*>(data.data()),
                    static_cast<DWORD>(
                        data.size() * sizeof(wchar_t)
                        )
                );

                SetLastError(error);
                return error == ERROR_SUCCESS;
            }

            SetLastError(ERROR_UNSUPPORTED_TYPE);
            return false;
        }

        std::wstring DwordToString(DWORD value)
        {
            return std::to_wstring(value);
        }

        bool ReadRegistryValue(
            const ParameterDefinition& definition,
            ParameterInfo& result)
        {
            HKEY key = nullptr;

            LONG error = RegOpenKeyExW(
                HKEY_LOCAL_MACHINE,
                definition.keyPath,
                0,
                KEY_QUERY_VALUE | GetRegistryView(),
                &key
            );

            if (error != ERROR_SUCCESS)
            {
                result.errorCode = error;
                result.readable = false;
                result.exists = false;
                return false;
            }

            DWORD type = REG_NONE;
            DWORD size = 0;

            error = RegQueryValueExW(
                key,
                definition.valueName,
                nullptr,
                &type,
                nullptr,
                &size
            );

            if (error != ERROR_SUCCESS)
            {
                RegCloseKey(key);

                if (error == ERROR_FILE_NOT_FOUND &&
                    definition.expectedType == REG_SZ &&
                    definition.expectedValue[0] == L'\0')
                {
                    result.exists = false;
                    result.readable = true;
                    result.currentValue.clear();
                    result.registryType = REG_SZ;
                    result.errorCode = ERROR_SUCCESS;
                    return true;
                }

                result.errorCode = error;
                result.readable = false;
                result.exists = false;
                return false;
            }

            result.exists = true;
            result.registryType = type;

            if (size > MAX_VALUE_SIZE)
            {
                RegCloseKey(key);
                result.errorCode = ERROR_INVALID_DATA;
                result.readable = false;
                return false;
            }

            if (type == REG_DWORD)
            {
                if (size != sizeof(DWORD))
                {
                    RegCloseKey(key);
                    result.errorCode = ERROR_INVALID_DATA;
                    result.readable = false;
                    return false;
                }

                DWORD value = 0;

                error = RegQueryValueExW(
                    key,
                    definition.valueName,
                    nullptr,
                    nullptr,
                    reinterpret_cast<LPBYTE>(&value),
                    &size
                );

                RegCloseKey(key);

                if (error != ERROR_SUCCESS)
                {
                    result.errorCode = error;
                    result.readable = false;
                    return false;
                }

                result.currentValue = DwordToString(value);
            }
            else if (type == REG_SZ ||
                type == REG_EXPAND_SZ ||
                type == REG_MULTI_SZ)
            {
                if (size % sizeof(wchar_t) != 0)
                {
                    RegCloseKey(key);
                    result.errorCode = ERROR_INVALID_DATA;
                    result.readable = false;
                    return false;
                }

                std::vector<wchar_t> buffer(
                    size / sizeof(wchar_t) + 2,
                    L'\0'
                );

                error = RegQueryValueExW(
                    key,
                    definition.valueName,
                    nullptr,
                    nullptr,
                    reinterpret_cast<LPBYTE>(buffer.data()),
                    &size
                );

                RegCloseKey(key);

                if (error != ERROR_SUCCESS)
                {
                    result.errorCode = error;
                    result.readable = false;
                    return false;
                }

                if (type == REG_MULTI_SZ)
                {
                    const size_t count =
                        size / sizeof(wchar_t);

                    result.currentValue.clear();

                    size_t i = 0;

                    while (i < count && buffer[i] != L'\0')
                    {
                        size_t start = i;

                        while (i < count && buffer[i] != L'\0')
                            ++i;

                        if (!result.currentValue.empty())
                            result.currentValue += L"\n";

                        result.currentValue.append(
                            buffer.data() + start,
                            i - start
                        );

                        if (i < count)
                            ++i;
                    }
                }
                else
                {
                    result.currentValue.assign(
                        buffer.data(),
                        size / sizeof(wchar_t)
                    );

                    const size_t nullPosition =
                        result.currentValue.find(L'\0');

                    if (nullPosition != std::wstring::npos)
                    {
                        result.currentValue.resize(nullPosition);
                    }
                }
            }
            else
            {
                RegCloseKey(key);
                result.errorCode = ERROR_UNSUPPORTED_TYPE;
                result.readable = false;
                return false;
            }

            result.readable = true;
            result.errorCode = ERROR_SUCCESS;

            return true;
        }
    }

    ParameterInfo GetParameterInfo(Parameter parameter)
    {
        ParameterInfo result{};

        const auto* definition = FindDefinition(parameter);

        if (!definition)
        {
            result.errorCode = ERROR_INVALID_PARAMETER;
            return result;
        }

        result.parameter = definition->parameter;
        result.name = definition->name;
        result.keyPath = definition->keyPath;
        result.valueName = definition->valueName;
        result.expectedValue = definition->expectedValue;
        result.registryType = definition->expectedType;

        return result;
    }

    bool ReadParameter(
        Parameter parameter,
        ParameterInfo& result)
    {
        result = GetParameterInfo(parameter);

        const auto* definition = FindDefinition(parameter);

        if (!definition)
            return false;

        if (!ReadRegistryValue(*definition, result))
            return false;

        CheckParameter(result);
        return true;
    }

    bool ReadAllParameters(
        ParameterInfo results[],
        size_t count)
    {
        if (!results || count < PARAMETER_COUNT)
            return false;

        const Parameter parameters[PARAMETER_COUNT] =
        {
            Parameter::Shell,
            Parameter::Userinit,
            Parameter::CmdLine,
            Parameter::AppInitDlls,
            Parameter::SetupType,
            Parameter::CursorSuppression,
            Parameter::BootExecute
        };

        bool allReadable = true;

        for (size_t i = 0; i < PARAMETER_COUNT; ++i)
        {
            if (!ReadParameter(parameters[i], results[i]))
                allReadable = false;
        }

        return allReadable;
    }

    bool CheckParameter(ParameterInfo& info)
    {
        info.matchesExpected = false;

        if (!info.readable)
            return false;

        const auto* definition =
            FindDefinition(info.parameter);

        if (!definition ||
            info.registryType != definition->expectedType)
        {
            return false;
        }

        info.matchesExpected =
            info.currentValue == info.expectedValue;

        return info.matchesExpected;
    }

    bool CreateBackup(
        Parameter parameter,
        BackupInfo& backup)
    {
        backup = BackupInfo{};
        backup.parameter = parameter;

        const auto* definition = FindDefinition(parameter);

        if (!definition)
            return false;

        HKEY key = nullptr;

        LONG error = RegOpenKeyExW(
            HKEY_LOCAL_MACHINE,
            definition->keyPath,
            0,
            KEY_QUERY_VALUE | GetRegistryView(),
            &key
        );

        if (error != ERROR_SUCCESS)
            return false;

        DWORD type = REG_NONE;
        DWORD size = 0;

        error = RegQueryValueExW(
            key,
            definition->valueName,
            nullptr,
            &type,
            nullptr,
            &size
        );

        if (error == ERROR_FILE_NOT_FOUND)
        {
            RegCloseKey(key);
            backup.valueExisted = false;
            backup.valid = true;
            return true;
        }

        if (error != ERROR_SUCCESS ||
            size > MAX_VALUE_SIZE)
        {
            RegCloseKey(key);
            return false;
        }

        std::vector<BYTE> data(size);

        error = RegQueryValueExW(
            key,
            definition->valueName,
            nullptr,
            &type,
            data.empty() ? nullptr : data.data(),
            &size
        );

        RegCloseKey(key);

        if (error != ERROR_SUCCESS)
            return false;

        data.resize(size);

        backup.registryType = type;
        backup.data = std::move(data);
        backup.valueExisted = true;
        backup.valid = true;

        return true;
    }

    bool RestoreBackup(
        const BackupInfo& backup,
        LONG& errorCode)
    {
        errorCode = ERROR_SUCCESS;

        if (!backup.valid ||
            !IsRestorableParameter(backup.parameter))
        {
            errorCode = ERROR_INVALID_PARAMETER;
            return false;
        }

        const auto* definition =
            FindDefinition(backup.parameter);

        if (!definition)
        {
            errorCode = ERROR_INVALID_PARAMETER;
            return false;
        }

        HKEY key = nullptr;

        LONG error = RegOpenKeyExW(
            HKEY_LOCAL_MACHINE,
            definition->keyPath,
            0,
            KEY_SET_VALUE | GetRegistryView(),
            &key
        );

        if (error != ERROR_SUCCESS)
        {
            errorCode = error;
            return false;
        }

        if (backup.valueExisted)
        {
            if (backup.data.size() > MAXDWORD)
            {
                RegCloseKey(key);
                errorCode = ERROR_INVALID_DATA;
                return false;
            }

            error = RegSetValueExW(
                key,
                definition->valueName,
                0,
                backup.registryType,
                backup.data.empty()
                ? nullptr
                : backup.data.data(),
                static_cast<DWORD>(backup.data.size())
            );
        }
        else
        {
            error = RegDeleteValueW(
                key,
                definition->valueName
            );

            if (error == ERROR_FILE_NOT_FOUND)
                error = ERROR_SUCCESS;
        }

        RegCloseKey(key);

        errorCode = error;
        return error == ERROR_SUCCESS;
    }

    bool RestoreDefault(
        Parameter parameter,
        BackupInfo& backup,
        LONG& errorCode)
    {
        errorCode = ERROR_SUCCESS;
        backup = BackupInfo{};

        if (!IsRestorableParameter(parameter))
        {
            errorCode = ERROR_INVALID_PARAMETER;
            return false;
        }

        if ((parameter == Parameter::CmdLine ||
            parameter == Parameter::SetupType ||
            parameter == Parameter::BootExecute) &&
            IsWindowsSetupActive())
        {
            errorCode = ERROR_BUSY;
            return false;
        }

        const auto* definition = FindDefinition(parameter);

        if (!definition)
        {
            errorCode = ERROR_INVALID_PARAMETER;
            return false;
        }

        if (!CreateBackup(parameter, backup))
        {
            errorCode = ERROR_READ_FAULT;
            backup = BackupInfo{};
            return false;
        }

        HKEY key = nullptr;

        LONG error = RegOpenKeyExW(
            HKEY_LOCAL_MACHINE,
            definition->keyPath,
            0,
            KEY_SET_VALUE | GetRegistryView(),
            &key
        );

        if (error != ERROR_SUCCESS)
        {
            errorCode = error;
            backup = BackupInfo{};
            return false;
        }

        const bool writeSuccess =
            WriteExpectedValue(key, *definition);

        if (!writeSuccess)
            error = GetLastError();

        RegCloseKey(key);

        if (!writeSuccess)
        {
            LONG originalError = error;
            LONG rollbackError = ERROR_SUCCESS;

            if (!RestoreBackup(backup, rollbackError))
                errorCode = rollbackError;
            else
            {
                errorCode = originalError;
                backup = BackupInfo{};
            }

            return false;
        }

        ParameterInfo verification{};

        if (!ReadParameter(parameter, verification) ||
            !verification.matchesExpected)
        {
            LONG verificationError =
                verification.errorCode != ERROR_SUCCESS
                ? verification.errorCode
                : ERROR_INVALID_DATA;

            LONG rollbackError = ERROR_SUCCESS;

            if (!RestoreBackup(backup, rollbackError))
                errorCode = rollbackError;
            else
            {
                errorCode = verificationError;
                backup = BackupInfo{};
            }

            return false;
        }

        return true;
    }


    bool SetCustomValue(
        Parameter parameter,
        const std::wstring& value,
        BackupInfo& backup,
        LONG& errorCode)
    {
        errorCode = ERROR_SUCCESS;
        backup = BackupInfo{};

        const auto* definition = FindDefinition(parameter);
        if (!definition)
        {
            errorCode = ERROR_INVALID_PARAMETER;
            return false;
        }

        if ((parameter == Parameter::CmdLine ||
             parameter == Parameter::SetupType ||
             parameter == Parameter::BootExecute) &&
            IsWindowsSetupActive())
        {
            errorCode = ERROR_BUSY;
            return false;
        }

        if (!CreateBackup(parameter, backup))
        {
            errorCode = ERROR_READ_FAULT;
            backup = BackupInfo{};
            return false;
        }

        DWORD type = definition->expectedType;
        std::vector<BYTE> bytes;

        if (type == REG_DWORD)
        {
            DWORD number = 0;
            if (!ParseDword(value.c_str(), number))
            {
                errorCode = ERROR_INVALID_DATA;
                backup = BackupInfo{};
                return false;
            }
            bytes.resize(sizeof(number));
            memcpy(bytes.data(), &number, sizeof(number));
        }
        else if (type == REG_SZ || type == REG_EXPAND_SZ)
        {
            if (value.find(L'\0') != std::wstring::npos)
            {
                errorCode = ERROR_INVALID_DATA;
                backup = BackupInfo{};
                return false;
            }
            bytes.resize((value.size() + 1) * sizeof(wchar_t));
            memcpy(bytes.data(), value.c_str(), bytes.size());
        }
        else if (type == REG_MULTI_SZ)
        {
            std::vector<wchar_t> multi;
            size_t start = 0;
            while (start < value.size())
            {
                size_t end = value.find(L'\n', start);
                if (end == std::wstring::npos) end = value.size();
                size_t lineEnd = end;
                if (lineEnd > start && value[lineEnd - 1] == L'\r') --lineEnd;
                if (lineEnd > start)
                {
                    multi.insert(multi.end(), value.begin() + start, value.begin() + lineEnd);
                    multi.push_back(L'\0');
                }
                start = end + 1;
            }
            if (multi.empty() || multi.back() != L'\0') multi.push_back(L'\0');
            multi.push_back(L'\0');
            bytes.resize(multi.size() * sizeof(wchar_t));
            memcpy(bytes.data(), multi.data(), bytes.size());
        }
        else
        {
            errorCode = ERROR_UNSUPPORTED_TYPE;
            backup = BackupInfo{};
            return false;
        }

        HKEY key = nullptr;
        LONG error = RegOpenKeyExW(HKEY_LOCAL_MACHINE, definition->keyPath, 0,
            KEY_SET_VALUE | GetRegistryView(), &key);
        if (error != ERROR_SUCCESS)
        {
            errorCode = error;
            backup = BackupInfo{};
            return false;
        }

        error = RegSetValueExW(key, definition->valueName, 0, type,
            bytes.empty() ? nullptr : bytes.data(),
            static_cast<DWORD>(bytes.size()));
        RegCloseKey(key);

        if (error != ERROR_SUCCESS)
        {
            LONG rollbackError = ERROR_SUCCESS;
            if (!RestoreBackup(backup, rollbackError))
                errorCode = rollbackError;
            else
                errorCode = error;
            return false;
        }

        std::wstring normalizedValue = value;
        if (type == REG_MULTI_SZ)
        {
            normalizedValue.clear();
            size_t start = 0;
            while (start < value.size())
            {
                size_t end = value.find(L'\n', start);
                if (end == std::wstring::npos) end = value.size();
                size_t lineEnd = end;
                if (lineEnd > start && value[lineEnd - 1] == L'\r') --lineEnd;
                if (lineEnd > start)
                {
                    if (!normalizedValue.empty()) normalizedValue += L"\n";
                    normalizedValue.append(value, start, lineEnd - start);
                }
                start = end + 1;
            }
        }

        ParameterInfo verify{};
        if (!ReadParameter(parameter, verify) || !verify.readable ||
            verify.currentValue != normalizedValue)
        {
            LONG rollbackError = ERROR_SUCCESS;
            if (!RestoreBackup(backup, rollbackError))
                errorCode = rollbackError;
            else
                errorCode = ERROR_INVALID_DATA;
            return false;
        }

        return true;
    }

    std::wstring GetErrorMessage(LONG errorCode)
    {
        switch (errorCode)
        {
        case ERROR_SUCCESS:
            return L"OK";

        case ERROR_FILE_NOT_FOUND:
            return L"Значение не найдено";

        case ERROR_PATH_NOT_FOUND:
            return L"Раздел реестра не найден";

        case ERROR_ACCESS_DENIED:
            return L"Отказано в доступе";

        case ERROR_INVALID_DATA:
            return L"Некорректные данные";

        case ERROR_UNSUPPORTED_TYPE:
            return L"Неподдерживаемый тип данных";

        case ERROR_INVALID_PARAMETER:
            return L"Некорректный параметр";

        case ERROR_MORE_DATA:
            return L"Размер данных изменился во время чтения";

        case ERROR_READ_FAULT:
            return L"Не удалось прочитать резервную копию";

        case ERROR_BUSY:
            return L"Выполняется настройка Windows; изменение отложено";

        default:
            return L"Ошибка Windows: " +
                std::to_wstring(errorCode);
        }
    }
}