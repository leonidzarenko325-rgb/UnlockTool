#include "AppearanceRepair.h"

#include <shellapi.h>

#pragma comment(lib, "Shell32.lib")

namespace AppearanceRepair
{
    OperationResult RestoreDefaultTheme()
    {
        wchar_t windowsDirectory[MAX_PATH]{};

        UINT length = GetWindowsDirectoryW(
            windowsDirectory,
            MAX_PATH
        );

        if (length == 0 || length >= MAX_PATH)
        {
            return {
                false,
                L"Не удалось определить папку Windows."
            };
        }

        std::wstring themePath =
            std::wstring(windowsDirectory) +
            L"\\Resources\\Themes\\aero.theme";

        DWORD attributes = GetFileAttributesW(
            themePath.c_str()
        );

        if (attributes == INVALID_FILE_ATTRIBUTES)
        {
            return {
                false,
                L"Стандартная тема aero.theme не найдена."
            };
        }

        HINSTANCE result = ShellExecuteW(
            nullptr,
            L"open",
            themePath.c_str(),
            nullptr,
            nullptr,
            SW_SHOWNORMAL
        );

        if (reinterpret_cast<INT_PTR>(result) <= 32)
        {
            return {
                false,
                L"Не удалось открыть стандартную тему Windows."
            };
        }

        return {
            true,
            L"Запущено применение стандартной темы Windows."
        };
    }

    OperationResult RestoreFontSmoothing()
    {
        if (!SystemParametersInfoW(
            SPI_SETFONTSMOOTHING,
            TRUE,
            nullptr,
            SPIF_UPDATEINIFILE | SPIF_SENDCHANGE
        ))
        {
            return {
                false,
                L"Не удалось включить сглаживание шрифтов."
            };
        }

        // Уведомляем приложения об изменении системных настроек.
        DWORD_PTR response = 0;

        SendMessageTimeoutW(
            HWND_BROADCAST,
            WM_SETTINGCHANGE,
            0,
            reinterpret_cast<LPARAM>(L"WindowMetrics"),
            SMTO_ABORTIFHUNG,
            3000,
            &response
        );

        return {
            true,
            L"Сглаживание системных шрифтов включено."
        };
    }

    OperationResult RestoreDefaultAppearance()
    {
        OperationResult fonts = RestoreFontSmoothing();

        if (!fonts.success)
            return fonts;

        OperationResult theme = RestoreDefaultTheme();

        if (!theme.success)
            return theme;

        return {
            true,
            L"Команды восстановления оформления выполнены."
        };
    }
}