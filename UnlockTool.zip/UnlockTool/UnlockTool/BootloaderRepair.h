#pragma once

#include <Windows.h>
#include <string>

namespace BootloaderRepair
{
    enum class FirmwareType
    {
        UEFI,
        BIOS,
        All
    };

    struct RepairResult
    {
        bool success = false;
        DWORD exitCode = 0;
        std::wstring message;
    };

    // Проверка указанной установки Windows.
    bool ValidateWindowsDirectory(
        const std::wstring& windowsDirectory
    );

    // Проверка доступности выбранного системного раздела.
    bool ValidateSystemPartition(
        const std::wstring& partition
    );

    // Восстановление загрузочных файлов через BCDBoot.
    RepairResult Repair(
        const std::wstring& windowsDirectory,
        const std::wstring& systemPartition,
        FirmwareType firmware
    );
}