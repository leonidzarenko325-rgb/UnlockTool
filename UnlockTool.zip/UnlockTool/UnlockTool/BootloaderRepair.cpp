#include "BootloaderRepair.h"

#include <shellapi.h>
#include <vector>

namespace BootloaderRepair
{
    bool ValidateWindowsDirectory(
        const std::wstring& windowsDirectory
    )
    {
        if (windowsDirectory.empty())
            return false;

        std::wstring systemFile =
            windowsDirectory + L"\\System32\\config\\SYSTEM";

        DWORD attributes = GetFileAttributesW(
            systemFile.c_str()
        );

        return attributes != INVALID_FILE_ATTRIBUTES &&
            !(attributes & FILE_ATTRIBUTE_DIRECTORY);
    }

    bool ValidateSystemPartition(
        const std::wstring& partition
    )
    {
        if (partition.size() != 2 ||
            partition[1] != L':')
            return false;

        wchar_t root[] = {
            partition[0], L':', L'\\', L'\0'
        };

        return GetDriveTypeW(root) != DRIVE_NO_ROOT_DIR;
    }

    RepairResult Repair(
        const std::wstring& windowsDirectory,
        const std::wstring& systemPartition,
        FirmwareType firmware
    )
    {
        RepairResult result{};

        if (!ValidateWindowsDirectory(windowsDirectory))
        {
            result.message =
                L"Указанная папка Windows не прошла проверку.";

            return result;
        }

        if (!ValidateSystemPartition(systemPartition))
        {
            result.message =
                L"Указан недоступный или некорректный раздел.";

            return result;
        }

        std::wstring firmwareArgument;

        switch (firmware)
        {
        case FirmwareType::UEFI:
            firmwareArgument = L"UEFI";
            break;

        case FirmwareType::BIOS:
            firmwareArgument = L"BIOS";
            break;

        case FirmwareType::All:
            firmwareArgument = L"ALL";
            break;

        default:
            result.message = L"Неизвестный тип прошивки.";
            return result;
        }

        std::wstring command =
            L"bcdboot.exe \"" +
            windowsDirectory +
            L"\" /s " +
            systemPartition +
            L" /f " +
            firmwareArgument;

        std::vector<wchar_t> commandLine(
            command.begin(),
            command.end()
        );

        commandLine.push_back(L'\0');

        STARTUPINFOW startup{};
        startup.cb = sizeof(startup);
        startup.dwFlags = STARTF_USESHOWWINDOW;
        startup.wShowWindow = SW_HIDE;

        PROCESS_INFORMATION process{};

        BOOL created = CreateProcessW(
            nullptr,
            commandLine.data(),
            nullptr,
            nullptr,
            FALSE,
            CREATE_NO_WINDOW,
            nullptr,
            nullptr,
            &startup,
            &process
        );

        if (!created)
        {
            result.message =
                L"Не удалось запустить BCDBoot. Код ошибки: " +
                std::to_wstring(GetLastError());

            return result;
        }

        WaitForSingleObject(
            process.hProcess,
            INFINITE
        );

        DWORD exitCode = 0;

        GetExitCodeProcess(
            process.hProcess,
            &exitCode
        );

        CloseHandle(process.hThread);
        CloseHandle(process.hProcess);

        result.exitCode = exitCode;
        result.success = (exitCode == 0);

        result.message = result.success
            ? L"Команда BCDBoot завершилась успешно."
            : L"BCDBoot завершился с ошибкой. Код: " +
            std::to_wstring(exitCode);

        return result;
    }
}