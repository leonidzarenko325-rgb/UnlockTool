#pragma once

#include <Windows.h>
#include <string>
#include <vector>
#include <cstddef>

namespace RegistryRepair
{
    enum class Parameter
    {
        Shell,
        Userinit,
        CmdLine,
        AppInitDlls,
        SetupType,
        CursorSuppression,
        BootExecute
    };

    struct ParameterInfo
    {
        Parameter parameter{};

        std::wstring name;
        std::wstring keyPath;
        std::wstring valueName;

        std::wstring currentValue;
        std::wstring expectedValue;

        DWORD registryType = REG_NONE;
        LONG errorCode = ERROR_SUCCESS;

        bool exists = false;
        bool readable = false;
        bool matchesExpected = false;
    };

    struct BackupInfo
    {
        Parameter parameter{};

        DWORD registryType = REG_NONE;
        std::vector<BYTE> data;

        bool valueExisted = false;
        bool valid = false;
    };

    ParameterInfo GetParameterInfo(Parameter parameter);

    bool ReadParameter(
        Parameter parameter,
        ParameterInfo& result
    );

    bool ReadAllParameters(
        ParameterInfo results[],
        size_t count
    );

    bool CheckParameter(ParameterInfo& info);

    bool CreateBackup(
        Parameter parameter,
        BackupInfo& backup
    );

    bool RestoreBackup(
        const BackupInfo& backup,
        LONG& errorCode
    );

    bool RestoreDefault(
        Parameter parameter,
        BackupInfo& backup,
        LONG& errorCode
    );

    // Writes a user-supplied value while preserving the parameter's registry type.
    // A raw backup is captured first and used for rollback if the write fails.
    bool SetCustomValue(
        Parameter parameter,
        const std::wstring& value,
        BackupInfo& backup,
        LONG& errorCode
    );

    std::wstring GetErrorMessage(LONG errorCode);
}