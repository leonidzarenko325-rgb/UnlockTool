#pragma once

#include <Windows.h>
#include <string>
#include <vector>

namespace DebuggerDetector
{
    enum class RegistryHive
    {
        LocalMachine,
        CurrentUser
    };

    struct DebuggerEntry
    {
        RegistryHive hive = RegistryHive::LocalMachine;
        REGSAM registryView = KEY_WOW64_64KEY;

        std::wstring imageName;
        std::wstring debuggerPath;
        std::wstring registryPath;

        DWORD valueType = REG_SZ;
    };

    std::vector<DebuggerEntry> Scan();

    bool Remove(
        const DebuggerEntry& entry,
        const std::wstring& backupFile,
        std::wstring& error
    );
}