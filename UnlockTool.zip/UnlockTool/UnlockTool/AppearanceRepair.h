#pragma once

#include <Windows.h>
#include <string>

namespace AppearanceRepair
{
    struct OperationResult
    {
        bool success = false;
        std::wstring message;
    };

    // Открыть стандартную тему Windows.
    OperationResult RestoreDefaultTheme();

    // Восстановить стандартное сглаживание системных шрифтов.
    OperationResult RestoreFontSmoothing();

    // Выполнить обе операции.
    OperationResult RestoreDefaultAppearance();
}